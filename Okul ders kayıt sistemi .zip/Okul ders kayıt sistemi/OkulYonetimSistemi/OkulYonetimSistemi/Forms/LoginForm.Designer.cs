namespace WindowsFormsApp6
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.lblAppName = new System.Windows.Forms.Label();
            this.lblTagline = new System.Windows.Forms.Label();
            this.pnlCard = new System.Windows.Forms.Panel();
            this.lblLoginTitle = new System.Windows.Forms.Label();
            this.lblTCLabel = new System.Windows.Forms.Label();
            this.txtTC = new System.Windows.Forms.TextBox();
            this.lblSifreLabel = new System.Windows.Forms.Label();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.pnlTabs = new System.Windows.Forms.Panel();
            this.btnTabOgrenci = new System.Windows.Forms.Button();
            this.btnTabOgretmen = new System.Windows.Forms.Button();
            this.btnTabAdmin = new System.Windows.Forms.Button();
            this.lblHata = new System.Windows.Forms.Label();
            this.btnGiris = new System.Windows.Forms.Button();
            this.pnlLeft.SuspendLayout();
            this.pnlCard.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLeft
            // 
            this.pnlLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.pnlLeft.Controls.Add(this.lblAppName);
            this.pnlLeft.Controls.Add(this.lblTagline);
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(457, 597);
            this.pnlLeft.TabIndex = 0;
            // 
            // lblAppName
            // 
            this.lblAppName.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Bold);
            this.lblAppName.ForeColor = System.Drawing.Color.White;
            this.lblAppName.Location = new System.Drawing.Point(40, 81);
            this.lblAppName.Name = "lblAppName";
            this.lblAppName.Size = new System.Drawing.Size(366, 256);
            this.lblAppName.TabIndex = 0;
            this.lblAppName.Text = "Okul\nDers Kayıt ve Yönetim\nSistemi";
            this.lblAppName.Click += new System.EventHandler(this.lblAppName_Click);
            // 
            // lblTagline
            // 
            this.lblTagline.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblTagline.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(220)))), ((int)(((byte)(255)))));
            this.lblTagline.Location = new System.Drawing.Point(46, 363);
            this.lblTagline.Name = "lblTagline";
            this.lblTagline.Size = new System.Drawing.Size(366, 64);
            this.lblTagline.TabIndex = 1;
            this.lblTagline.Text = "Öğrenci ve öğretmenler için\nakıllı okul yönetim platformu";
            // 
            // pnlCard
            // 
            this.pnlCard.BackColor = System.Drawing.Color.White;
            this.pnlCard.Controls.Add(this.lblLoginTitle);
            this.pnlCard.Controls.Add(this.lblTCLabel);
            this.pnlCard.Controls.Add(this.txtTC);
            this.pnlCard.Controls.Add(this.lblSifreLabel);
            this.pnlCard.Controls.Add(this.txtSifre);
            this.pnlCard.Controls.Add(this.pnlTabs);
            this.pnlCard.Controls.Add(this.lblHata);
            this.pnlCard.Controls.Add(this.btnGiris);
            this.pnlCard.Location = new System.Drawing.Point(514, 69);
            this.pnlCard.Name = "pnlCard";
            this.pnlCard.Size = new System.Drawing.Size(434, 459);
            this.pnlCard.TabIndex = 1;
            // 
            // lblLoginTitle
            // 
            this.lblLoginTitle.AutoSize = true;
            this.lblLoginTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblLoginTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.lblLoginTitle.Location = new System.Drawing.Point(46, 32);
            this.lblLoginTitle.Name = "lblLoginTitle";
            this.lblLoginTitle.Size = new System.Drawing.Size(128, 37);
            this.lblLoginTitle.TabIndex = 0;
            this.lblLoginTitle.Text = "Giriş Yap";
            // 
            // lblTCLabel
            // 
            this.lblTCLabel.AutoSize = true;
            this.lblTCLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblTCLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lblTCLabel.Location = new System.Drawing.Point(46, 94);
            this.lblTCLabel.Name = "lblTCLabel";
            this.lblTCLabel.Size = new System.Drawing.Size(99, 20);
            this.lblTCLabel.TabIndex = 1;
            this.lblTCLabel.Text = "TC Kimlik No";
            // 
            // txtTC
            // 
            this.txtTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTC.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTC.Location = new System.Drawing.Point(46, 117);
            this.txtTC.MaxLength = 11;
            this.txtTC.Name = "txtTC";
            this.txtTC.Size = new System.Drawing.Size(343, 30);
            this.txtTC.TabIndex = 2;
            // 
            // lblSifreLabel
            // 
            this.lblSifreLabel.AutoSize = true;
            this.lblSifreLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblSifreLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lblSifreLabel.Location = new System.Drawing.Point(46, 164);
            this.lblSifreLabel.Name = "lblSifreLabel";
            this.lblSifreLabel.Size = new System.Drawing.Size(41, 20);
            this.lblSifreLabel.TabIndex = 3;
            this.lblSifreLabel.Text = "Şifre";
            // 
            // txtSifre
            // 
            this.txtSifre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSifre.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSifre.Location = new System.Drawing.Point(46, 188);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '●';
            this.txtSifre.Size = new System.Drawing.Size(343, 30);
            this.txtSifre.TabIndex = 4;
            // 
            // pnlTabs
            // 
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.pnlTabs.Controls.Add(this.btnTabOgrenci);
            this.pnlTabs.Controls.Add(this.btnTabOgretmen);
            this.pnlTabs.Controls.Add(this.btnTabAdmin);
            this.pnlTabs.Location = new System.Drawing.Point(46, 230);
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Size = new System.Drawing.Size(343, 38);
            this.pnlTabs.TabIndex = 5;
            // 
            // btnTabOgrenci
            // 
            this.btnTabOgrenci.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btnTabOgrenci.FlatAppearance.BorderSize = 0;
            this.btnTabOgrenci.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabOgrenci.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTabOgrenci.ForeColor = System.Drawing.Color.White;
            this.btnTabOgrenci.Location = new System.Drawing.Point(0, 3);
            this.btnTabOgrenci.Name = "btnTabOgrenci";
            this.btnTabOgrenci.Size = new System.Drawing.Size(114, 32);
            this.btnTabOgrenci.TabIndex = 0;
            this.btnTabOgrenci.Text = "Öğrenci";
            this.btnTabOgrenci.UseVisualStyleBackColor = false;
            // 
            // btnTabOgretmen
            // 
            this.btnTabOgretmen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.btnTabOgretmen.FlatAppearance.BorderSize = 0;
            this.btnTabOgretmen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabOgretmen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTabOgretmen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(80)))), ((int)(((byte)(100)))));
            this.btnTabOgretmen.Location = new System.Drawing.Point(114, 3);
            this.btnTabOgretmen.Name = "btnTabOgretmen";
            this.btnTabOgretmen.Size = new System.Drawing.Size(114, 32);
            this.btnTabOgretmen.TabIndex = 1;
            this.btnTabOgretmen.Text = "Öğretmen";
            this.btnTabOgretmen.UseVisualStyleBackColor = false;
            // 
            // btnTabAdmin
            // 
            this.btnTabAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(245)))), ((int)(((byte)(249)))));
            this.btnTabAdmin.FlatAppearance.BorderSize = 0;
            this.btnTabAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabAdmin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTabAdmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(80)))), ((int)(((byte)(100)))));
            this.btnTabAdmin.Location = new System.Drawing.Point(229, 3);
            this.btnTabAdmin.Name = "btnTabAdmin";
            this.btnTabAdmin.Size = new System.Drawing.Size(114, 32);
            this.btnTabAdmin.TabIndex = 2;
            this.btnTabAdmin.Text = "Yönetici";
            this.btnTabAdmin.UseVisualStyleBackColor = false;
            // 
            // lblHata
            // 
            this.lblHata.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblHata.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.lblHata.Location = new System.Drawing.Point(46, 275);
            this.lblHata.Name = "lblHata";
            this.lblHata.Size = new System.Drawing.Size(343, 21);
            this.lblHata.TabIndex = 6;
            // 
            // btnGiris
            // 
            this.btnGiris.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btnGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGiris.FlatAppearance.BorderSize = 0;
            this.btnGiris.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGiris.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnGiris.ForeColor = System.Drawing.Color.White;
            this.btnGiris.Location = new System.Drawing.Point(46, 304);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(343, 45);
            this.btnGiris.TabIndex = 7;
            this.btnGiris.Text = "Giriş Yap →";
            this.btnGiris.UseVisualStyleBackColor = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.ClientSize = new System.Drawing.Size(1029, 597);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.pnlCard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Okul Yönetim Sistemi";
            this.pnlLeft.ResumeLayout(false);
            this.pnlCard.ResumeLayout(false);
            this.pnlCard.PerformLayout();
            this.pnlTabs.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Label lblAppName;
        private System.Windows.Forms.Label lblTagline;
        private System.Windows.Forms.Panel pnlCard;
        private System.Windows.Forms.Label lblLoginTitle;
        private System.Windows.Forms.Label lblTCLabel;
        private System.Windows.Forms.TextBox txtTC;
        private System.Windows.Forms.Label lblSifreLabel;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Panel pnlTabs;
        private System.Windows.Forms.Button btnTabOgrenci;
        private System.Windows.Forms.Button btnTabOgretmen;
        private System.Windows.Forms.Button btnTabAdmin;
        private System.Windows.Forms.Label lblHata;
        private System.Windows.Forms.Button btnGiris;
    }
}
