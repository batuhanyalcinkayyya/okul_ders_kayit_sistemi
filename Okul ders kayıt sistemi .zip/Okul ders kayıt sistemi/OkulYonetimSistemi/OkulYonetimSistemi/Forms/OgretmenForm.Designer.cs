namespace WindowsFormsApp6
{
    partial class OgretmenForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlSidebar     = new System.Windows.Forms.Panel();
            this.pnlTopBar      = new System.Windows.Forms.Panel();
            this.pnlContent     = new System.Windows.Forms.Panel();
            this.lblPageTitle   = new System.Windows.Forms.Label();
            this.lblLogo        = new System.Windows.Forms.Label();
            this.btnDersProgram  = new System.Windows.Forms.Button();
            this.btnOgrenciler   = new System.Windows.Forms.Button();
            this.btnDevamsizlik  = new System.Windows.Forms.Button();
            this.btnSinav        = new System.Windows.Forms.Button();
            this.btnNotGuncelle  = new System.Windows.Forms.Button();
            this.btnBildirim     = new System.Windows.Forms.Button();
            this.btnCikis        = new System.Windows.Forms.Button();

            this.lblKullanici = new System.Windows.Forms.Label();
            this.lblUnvan     = new System.Windows.Forms.Label();
            this.pnlUser      = new System.Windows.Forms.Panel();
            this.pnlSidebar.SuspendLayout();
            this.pnlTopBar.SuspendLayout();
            this.SuspendLayout();

            // pnlSidebar
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.pnlSidebar.Controls.Add(this.lblLogo);
            this.pnlSidebar.Controls.Add(this.pnlUser);
            this.pnlSidebar.Controls.Add(this.btnDersProgram);
            this.pnlSidebar.Controls.Add(this.btnOgrenciler);
            this.pnlSidebar.Controls.Add(this.btnDevamsizlik);
            this.pnlSidebar.Controls.Add(this.btnSinav);
            this.pnlSidebar.Controls.Add(this.btnNotGuncelle);
            this.pnlSidebar.Controls.Add(this.btnBildirim);
            this.pnlSidebar.Controls.Add(this.btnCikis);
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Size     = new System.Drawing.Size(220, 660);

            // lblLogo
            this.lblLogo.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location  = new System.Drawing.Point(0, 25);
            this.lblLogo.Size      = new System.Drawing.Size(220, 30);
            this.lblLogo.Text      = "Öğretmen Paneli";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // pnlUser
            this.pnlUser.BackColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.pnlUser.Location  = new System.Drawing.Point(15, 65);
            this.pnlUser.Size      = new System.Drawing.Size(190, 60);
            this.pnlUser.Controls.Add(this.lblKullanici);
            this.pnlUser.Controls.Add(this.lblUnvan);

            // lblKullanici
            this.lblKullanici.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblKullanici.ForeColor = System.Drawing.Color.White;
            this.lblKullanici.Location  = new System.Drawing.Point(10, 8);
            this.lblKullanici.Size      = new System.Drawing.Size(170, 20);
            this.lblKullanici.Text      = "";

            // lblUnvan
            this.lblUnvan.Font      = new System.Drawing.Font("Segoe UI", 8F);
            this.lblUnvan.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.lblUnvan.Location  = new System.Drawing.Point(10, 32);
            this.lblUnvan.AutoSize  = true;
            this.lblUnvan.Text      = "Öğretmen";

            // btnDersProgram
            this.btnDersProgram.BackColor = System.Drawing.Color.Transparent;
            this.btnDersProgram.FlatAppearance.BorderSize = 0;
            this.btnDersProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDersProgram.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDersProgram.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnDersProgram.Location  = new System.Drawing.Point(0, 155);
            this.btnDersProgram.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnDersProgram.Size      = new System.Drawing.Size(220, 42);
            this.btnDersProgram.Text      = "Ders Programım";
            this.btnDersProgram.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnOgrenciler
            this.btnOgrenciler.BackColor = System.Drawing.Color.Transparent;
            this.btnOgrenciler.FlatAppearance.BorderSize = 0;
            this.btnOgrenciler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOgrenciler.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnOgrenciler.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnOgrenciler.Location  = new System.Drawing.Point(0, 205);
            this.btnOgrenciler.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnOgrenciler.Size      = new System.Drawing.Size(220, 42);
            this.btnOgrenciler.Text      = "Öğrencilerim";
            this.btnOgrenciler.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnDevamsizlik
            this.btnDevamsizlik.BackColor = System.Drawing.Color.Transparent;
            this.btnDevamsizlik.FlatAppearance.BorderSize = 0;
            this.btnDevamsizlik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevamsizlik.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDevamsizlik.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnDevamsizlik.Location  = new System.Drawing.Point(0, 255);
            this.btnDevamsizlik.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnDevamsizlik.Size      = new System.Drawing.Size(220, 42);
            this.btnDevamsizlik.Text      = "Devamsızlık Ekle";
            this.btnDevamsizlik.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnSinav
            this.btnSinav.BackColor = System.Drawing.Color.Transparent;
            this.btnSinav.FlatAppearance.BorderSize = 0;
            this.btnSinav.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSinav.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSinav.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnSinav.Location  = new System.Drawing.Point(0, 305);
            this.btnSinav.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnSinav.Size      = new System.Drawing.Size(220, 42);
            this.btnSinav.Text      = "Sınav Ekle";
            this.btnSinav.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnNotGuncelle
            this.btnNotGuncelle.BackColor = System.Drawing.Color.Transparent;
            this.btnNotGuncelle.FlatAppearance.BorderSize = 0;
            this.btnNotGuncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotGuncelle.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnNotGuncelle.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnNotGuncelle.Location  = new System.Drawing.Point(0, 355);
            this.btnNotGuncelle.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnNotGuncelle.Size      = new System.Drawing.Size(220, 42);
            this.btnNotGuncelle.Text      = "Not Gir / Güncelle";
            this.btnNotGuncelle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnBildirim
            this.btnBildirim.BackColor = System.Drawing.Color.Transparent;
            this.btnBildirim.FlatAppearance.BorderSize = 0;
            this.btnBildirim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBildirim.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBildirim.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnBildirim.Location  = new System.Drawing.Point(0, 405);
            this.btnBildirim.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnBildirim.Size      = new System.Drawing.Size(220, 42);
            this.btnBildirim.Text      = "Bildirim Gönder";
            this.btnBildirim.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnCikis
            this.btnCikis.BackColor = System.Drawing.Color.Transparent;
            this.btnCikis.FlatAppearance.BorderSize = 0;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCikis.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnCikis.Location  = new System.Drawing.Point(0, 590);
            this.btnCikis.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnCikis.Size      = new System.Drawing.Size(220, 42);
            this.btnCikis.Text      = "Çıkış";
            this.btnCikis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // pnlTopBar
            this.pnlTopBar.BackColor = System.Drawing.Color.White;
            this.pnlTopBar.Controls.Add(this.lblPageTitle);
            this.pnlTopBar.Location  = new System.Drawing.Point(220, 0);
            this.pnlTopBar.Size      = new System.Drawing.Size(880, 60);

            // lblPageTitle
            this.lblPageTitle.AutoSize  = true;
            this.lblPageTitle.Font      = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblPageTitle.Location  = new System.Drawing.Point(25, 18);
            this.lblPageTitle.Name      = "lblPageTitle";
            this.lblPageTitle.Text      = "Ders Programım";

            // pnlContent
            this.pnlContent.AutoScroll = true;
            this.pnlContent.BackColor  = System.Drawing.Color.FromArgb(248, 250, 252);
            this.pnlContent.Location   = new System.Drawing.Point(220, 60);
            this.pnlContent.Size       = new System.Drawing.Size(880, 600);

            // OgretmenForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode  = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor      = System.Drawing.Color.FromArgb(248, 250, 252);
            this.ClientSize     = new System.Drawing.Size(1100, 660);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlTopBar);
            this.Controls.Add(this.pnlSidebar);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text          = "Öğretmen Paneli";

            this.pnlTopBar.ResumeLayout(false);
            this.pnlTopBar.PerformLayout();
            this.pnlSidebar.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel  pnlSidebar;
        private System.Windows.Forms.Panel  pnlTopBar;
        private System.Windows.Forms.Panel  pnlContent;
        private System.Windows.Forms.Label  lblPageTitle;
        private System.Windows.Forms.Label  lblLogo;
        private System.Windows.Forms.Panel  pnlUser;
        private System.Windows.Forms.Label  lblKullanici;
        private System.Windows.Forms.Label  lblUnvan;
        private System.Windows.Forms.Button btnDersProgram;
        private System.Windows.Forms.Button btnOgrenciler;
        private System.Windows.Forms.Button btnDevamsizlik;
        private System.Windows.Forms.Button btnSinav;
        private System.Windows.Forms.Button btnNotGuncelle;
        private System.Windows.Forms.Button btnBildirim;
        private System.Windows.Forms.Button btnCikis;
    }
}
