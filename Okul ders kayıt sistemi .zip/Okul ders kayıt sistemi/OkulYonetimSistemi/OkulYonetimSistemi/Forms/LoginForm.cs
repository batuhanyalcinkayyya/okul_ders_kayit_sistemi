using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class LoginForm : Form
    {
        private int activeTab = 0;

        public LoginForm()
        {
            InitializeComponent();
            // Event'leri bağla
            this.btnTabOgrenci.Click  += (s, e) => SetActiveTab(2);
            this.btnTabOgretmen.Click += (s, e) => SetActiveTab(1);
            this.btnTabAdmin.Click    += (s, e) => SetActiveTab(0);
            // Başlangıçta Yönetici aktif
            SetActiveTab(0);
            this.btnGiris.Click       += BtnGiris_Click;
            this.txtTC.KeyPress       += (s, e) => {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            };
            this.txtTC.TextChanged += (s, e) => {
                string temiz = System.Text.RegularExpressions.Regex.Replace(txtTC.Text, @"[^0-9]", "");
                if (temiz.Length > 11) temiz = temiz.Substring(0, 11);
                if (txtTC.Text != temiz) {
                    int pos = txtTC.SelectionStart;
                    txtTC.Text = temiz;
                    txtTC.SelectionStart = Math.Min(pos, temiz.Length);
                }
                lblHata.Text = "";
            };
            this.txtTC.Leave += (s, e) => {
                if (txtTC.Text.Length == 11 && (txtTC.Text[10] - '0') % 2 != 0)
                    lblHata.Text = "Geçersiz TC Kimlik No (son hane çift olmalı)!";
            };
            try { this.Icon = new System.Drawing.Icon("42496school_99040.ico"); } catch { }
        }

        private void SetActiveTab(int idx)
        {
            activeTab = idx;
            Button[] tabs = { btnTabAdmin, btnTabOgretmen, btnTabOgrenci };
            for (int i = 0; i < tabs.Length; i++)
            {
                if (i == idx) {
                    tabs[i].BackColor = Theme.Primary;
                    tabs[i].ForeColor = Color.White;
                    tabs[i].Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
                } else {
                    tabs[i].BackColor = Color.FromArgb(241, 245, 249);
                    tabs[i].ForeColor = Theme.TextMain;
                    tabs[i].Font      = Theme.FontNormal;
                }
            }
        }

        private void BtnGiris_Click(object sender, EventArgs e)
        {
            lblHata.Text = "";
            string tc    = txtTC.Text.Trim();
            string sifre = txtSifre.Text.Trim();

            if (string.IsNullOrEmpty(tc) || string.IsNullOrEmpty(sifre))
            { lblHata.Text = "TC ve şifre boş bırakılamaz!"; return; }

            if (tc.Length != 11)
            { lblHata.Text = "TC Kimlik No tam 11 hane olmalıdır!"; return; }

            if ((tc[10] - '0') % 2 != 0)
            { lblHata.Text = "Geçersiz TC Kimlik No (son hane çift olmalı)!"; return; }

            if (!File.Exists(DbHelper.DbPath))
            { lblHata.Text = "Veritabanı bulunamadı!"; return; }

            try
            {
                if (activeTab == 2) // Öğrenci
                {
                    var dt = DbHelper.Query(
                        "SELECT OgrenciId, AdSoyad, SinifId FROM Ogrenciler WHERE TCKimlik=@tc AND Sifre=@s",
                        DbHelper.P("@tc", tc), DbHelper.P("@s", sifre));
                    if (dt.Rows.Count > 0) {
                        new OgrenciForm(Convert.ToInt32(dt.Rows[0]["OgrenciId"]),
                            dt.Rows[0]["AdSoyad"].ToString(), Convert.ToInt32(dt.Rows[0]["SinifId"])).Show();
                        txtTC.Text = "";
                        txtSifre.Text = "";
                        this.Hide();
                    } else lblHata.Text = "Hatalı TC veya şifre!";
                }
                else if (activeTab == 1) // Öğretmen
                {
                    var dt = DbHelper.Query(
                        "SELECT OgretmenId, AdSoyad FROM Ogretmenler WHERE TCKimlik=@tc AND Sifre=@s",
                        DbHelper.P("@tc", tc), DbHelper.P("@s", sifre));
                    if (dt.Rows.Count > 0) {
                        new OgretmenForm(Convert.ToInt32(dt.Rows[0]["OgretmenId"]),
                            dt.Rows[0]["AdSoyad"].ToString()).Show();
                        txtTC.Text = "";
                        txtSifre.Text = "";
                        this.Hide();
                    } else lblHata.Text = "Hatalı TC veya şifre!";
                }
                else // Yönetici
                {
                    var dt = DbHelper.Query(
                        "SELECT AdminId, AdSoyad FROM Adminler WHERE TCKimlik=@tc AND Sifre=@s",
                        DbHelper.P("@tc", tc), DbHelper.P("@s", sifre));
                    if (dt.Rows.Count > 0) {
                        new AdminForm(Convert.ToInt32(dt.Rows[0]["AdminId"]),
                            dt.Rows[0]["AdSoyad"].ToString()).Show();
                        txtTC.Text = "";
                        txtSifre.Text = "";
                        this.Hide();
                    } else lblHata.Text = "Hatalı TC veya şifre!";
                }
            }
            catch (Exception ex) { lblHata.Text = "Hata: " + ex.Message; }
        }

        private void lblAppName_Click(object sender, EventArgs e)
        {

        }
    }
}
