using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class OgrenciForm : Form
    {
        int ogrenciId, sinifId;
        string adSoyad;
        private Button activeBtn;

        public OgrenciForm(int id, string ad, int sinif)
        {
            ogrenciId = id; adSoyad = ad; sinifId = sinif;
            InitializeComponent();
            SetupEvents();
            ShowDersProgram();
        }

        private void SetupEvents()
        {
            this.FormClosing += (s, e) => { Application.OpenForms[0]?.Show(); };
            this.Resize += (s, e) => {
                pnlSidebar.Height = this.ClientSize.Height;
                pnlTopBar.Width   = this.ClientSize.Width - 220;
                pnlContent.Width  = this.ClientSize.Width - 220;
                pnlContent.Height = this.ClientSize.Height - 60;
                foreach (Control c in pnlContent.Controls)
                    if (c is DataGridView || c is Panel) c.Width = pnlContent.Width - c.Left - 20;
                if (activeBtn == btnDersProgrami) ShowDersProgram();
            };
            this.MaximizeBox     = true;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            lblAd.Text = adSoyad;
            try {
                var dt = DbHelper.Query("SELECT SinifAdi FROM Siniflar WHERE SinifId=@id", DbHelper.P("@id", sinifId));
                if (dt.Rows.Count > 0) lblSinif.Text = dt.Rows[0]["SinifAdi"].ToString();
            } catch {}
            btnDersProgrami.Click += (s, e) => { SetActive(btnDersProgrami); ShowDersProgram(); };
            btnNotlar.Click       += (s, e) => { SetActive(btnNotlar);       ShowNotlar(); };
            btnSinavTakvimi.Click += (s, e) => { SetActive(btnSinavTakvimi); ShowSinavTakvimi(); };
            btnBildirim.Click     += (s, e) => { SetActive(btnBildirim);     ShowBildirimler(); };
            btnCikis.Click        += (s, e) => { this.Close(); };
            try { this.Icon = new System.Drawing.Icon("42496school_99040.ico"); } catch { }
            SetActive(btnDersProgrami);
        }

        private Button MakeSideBtn(string text, int y)
        {
            var btn = new Button {
                Text = text,
                Location = new Point(0, y),
                Size = new Size(220, 42),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(200, 220, 255),
                Font = Theme.FontNormal,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(15, 0, 0, 0),
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(37, 78, 200);
            return btn;
        }

        private void SetActive(Button btn)
        {
            if (activeBtn != null)
            {
                activeBtn.BackColor = Color.Transparent;
                activeBtn.ForeColor = Color.FromArgb(200, 220, 255);
            }
            activeBtn = btn;
            btn.BackColor = Color.FromArgb(37, 99, 235);
            btn.ForeColor = Color.White;
        }

        private void SetPageTitle(string title)
        {
            var lbl = pnlTopBar.Controls["lblPageTitle"] as Label;
            if (lbl != null) lbl.Text = title;
        }

        // ─── DERS PROGRAMI ──────────────────────────────────────────────
        private void ShowDersProgram()
        {
            SetPageTitle("📅 Ders Programı");
            pnlContent.Controls.Clear();

            string[] gunler = { "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma" };
            int[] saatler = { 1, 2, 3, 4, 5, 6, 7, 8 };
            string[] saatEtiket = { "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00" };

            DataTable dt;
            try {
                dt = DbHelper.Query(
                    "SELECT dp.Gun, dp.Saat, d.DersAdi, o.AdSoyad AS Ogretmen " +
                    "FROM (DersProgrami dp " +
                    "INNER JOIN Dersler d ON dp.DersId = d.DersId) " +
                    "INNER JOIN Ogretmenler o ON dp.OgretmenId = o.OgretmenId " +
                    "WHERE dp.SinifId = @sid",
                    DbHelper.P("@sid", sinifId));
            } catch (Exception ex) {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20,20) });
                return;
            }

            int cellW = 155, cellH = 60, startX = 90, startY = 70;

            // Başlıklar - günler
            for (int g = 0; g < gunler.Length; g++)
            {
                var lbl = new Label {
                    Text = gunler[g],
                    Size = new Size(cellW, 36),
                    Location = new Point(startX + g * cellW, 25),
                    BackColor = Theme.Primary,
                    ForeColor = Color.White,
                    Font = Theme.FontBold,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlContent.Controls.Add(lbl);
            }

            // Saatler + hücreler
            for (int s = 0; s < saatler.Length; s++)
            {
                var lblSaat = new Label {
                    Text = saatEtiket[s],
                    Size = new Size(80, cellH),
                    Location = new Point(5, startY + s * cellH),
                    Font = Theme.FontSmall,
                    ForeColor = Theme.TextSub,
                    TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = Color.White
                };
                pnlContent.Controls.Add(lblSaat);

                for (int g = 0; g < gunler.Length; g++)
                {
                    string gun = gunler[g];
                    int saat = saatler[s];
                    string dersAdi = "", ogretmen = "";

                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["Gun"].ToString() == gun && Convert.ToInt32(row["Saat"]) == saat)
                        {
                            dersAdi = row["DersAdi"].ToString();
                            ogretmen = row["Ogretmen"].ToString();
                            break;
                        }
                    }

                    var cell = new Panel {
                        Size = new Size(cellW - 2, cellH - 2),
                        Location = new Point(startX + g * cellW, startY + s * cellH),
                        BackColor = string.IsNullOrEmpty(dersAdi) ? Color.FromArgb(248, 250, 252) : Color.FromArgb(239, 246, 255),
                        BorderStyle = BorderStyle.FixedSingle
                    };

                    if (!string.IsNullOrEmpty(dersAdi))
                    {
                        cell.Controls.Add(new Label {
                            Text = dersAdi,
                            Font = Theme.FontBold,
                            ForeColor = Theme.Primary,
                            Location = new Point(5, 5),
                            Size = new Size(cellW - 15, 22),
                            AutoEllipsis = true
                        });
                        cell.Controls.Add(new Label {
                            Text = "👤 " + ogretmen,
                            Font = Theme.FontSmall,
                            ForeColor = Theme.TextSub,
                            Location = new Point(5, 30),
                            Size = new Size(cellW - 15, 18),
                            AutoEllipsis = true
                        });
                    }
                    pnlContent.Controls.Add(cell);
                }
            }
        }

        // ─── NOTLAR & ORTALAMA ───────────────────────────────────────────
        private void ShowNotlar()
        {
            SetPageTitle("📊 Notlarım & Ortalama");
            pnlContent.Controls.Clear();

            DataTable dt;
            try {
                dt = DbHelper.Query(
                    "SELECT d.DersAdi, o.AdSoyad AS Ogretmen, k.Vize, k.Final, k.Devamsizlik, " +
                    "((k.Vize * 0.4) + (k.Final * 0.6)) AS Ortalama " +
                    "FROM (Kayitlar k " +
                    "INNER JOIN Dersler d ON k.DersId = d.DersId) " +
                    "INNER JOIN Ogretmenler o ON d.OgretmenId = o.OgretmenId " +
                    "WHERE k.OgrenciId = @id",
                    DbHelper.P("@id", ogrenciId));
            } catch (Exception ex) {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20,20) });
                return;
            }

            // Genel ortalama kartı
            double genelOrtalama = 0;
            int dersCount = 0;
            foreach (DataRow row in dt.Rows)
            {
                if (row["Ortalama"] != DBNull.Value)
                {
                    genelOrtalama += Convert.ToDouble(row["Ortalama"]);
                    dersCount++;
                }
            }
            if (dersCount > 0) genelOrtalama /= dersCount;

            var pnlOrtalama = new Panel {
                Location = new Point(20, 15),
                Size = new Size(pnlContent.Width - 40, 80),
                BackColor = genelOrtalama >= 50 ? Theme.Success : Theme.Danger
            };
            pnlOrtalama.Controls.Add(new Label {
                Text = $"Genel Ortalama: {genelOrtalama:F1}  " + (genelOrtalama >= 50 ? "✅ Geçer" : "❌ Kalır"),
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.White,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            });
            pnlContent.Controls.Add(pnlOrtalama);

            // Grid
            var dgv = MakeGrid();
            dgv.Location = new Point(20, 110);
            dgv.Size = new Size(pnlContent.Width - 40, 460);
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ders", DataPropertyName = "DersAdi", FillWeight = 25 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Öğretmen", DataPropertyName = "Ogretmen", FillWeight = 20 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Vize (%40)", DataPropertyName = "Vize", FillWeight = 15 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Final (%60)", DataPropertyName = "Final", FillWeight = 15 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ortalama", DataPropertyName = "Ortalama", FillWeight = 13 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Devamsızlık", DataPropertyName = "Devamsizlik", FillWeight = 12 });
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.DataSource = dt;

            // Ortalamayı renklendir
            dgv.CellFormatting += (s, e) => {
                if (e.ColumnIndex == 4 && e.Value != null && !(e.Value is DBNull))
                {
                    double val = Convert.ToDouble(e.Value);
                    e.Value = val.ToString("F1");
                    dgv.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = val >= 50 ? Theme.Success : Theme.Danger;
                    dgv.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.Font = Theme.FontBold;
                }
            };

            pnlContent.Controls.Add(dgv);
        }

        // ─── SINAV TAKVİMİ ───────────────────────────────────────────────
        private void ShowSinavTakvimi()
        {
            SetPageTitle("📋 Sınav Takvimi");
            pnlContent.Controls.Clear();

            DataTable dt;
            try {
                dt = DbHelper.Query(
                    "SELECT st.SinavAdi, d.DersAdi, st.SinavTarihi, st.SinavSaati, st.Aciklama " +
                    "FROM SinavTakvimi st INNER JOIN Dersler d ON st.DersId = d.DersId " +
                    "WHERE st.SinifId = @sid ORDER BY st.SinavTarihi",
                    DbHelper.P("@sid", sinifId));
            } catch (Exception ex) {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20,20) });
                return;
            }

            int y = 20;
            if (dt.Rows.Count == 0)
            {
                pnlContent.Controls.Add(new Label {
                    Text = "Henüz sınav eklenmemiş.",
                    Font = Theme.FontNormal, ForeColor = Theme.TextSub,
                    Location = new Point(20, 20), AutoSize = true
                });
                return;
            }

            foreach (DataRow row in dt.Rows)
            {
                DateTime tarih = Convert.ToDateTime(row["SinavTarihi"]);
                bool yaklasan = tarih >= DateTime.Today && tarih <= DateTime.Today.AddDays(7);

                var card = new Panel {
                    Location = new Point(20, y),
                    Size = new Size(pnlContent.Width - 40, 75),
                    BackColor = yaklasan ? Color.FromArgb(255, 251, 235) : Color.White,
                    BorderStyle = BorderStyle.FixedSingle
                };

                var lblDers = new Label {
                    Text = row["DersAdi"].ToString(),
                    Font = Theme.FontBold,
                    ForeColor = Theme.Primary,
                    Location = new Point(15, 10),
                    AutoSize = true
                };
                var lblSinav = new Label {
                    Text = row["SinavAdi"].ToString(),
                    Font = Theme.FontNormal,
                    ForeColor = Theme.TextMain,
                    Location = new Point(15, 35),
                    AutoSize = true
                };
                var lblTarih = new Label {
                    Text = $"📅 {tarih:dd MMMM yyyy}  🕐 {row["SinavSaati"]}",
                    Font = Theme.FontNormal,
                    ForeColor = yaklasan ? Theme.Warning : Theme.TextSub,
                    Location = new Point(400, 10),
                    AutoSize = true
                };
                var lblAciklama = new Label {
                    Text = row["Aciklama"].ToString(),
                    Font = Theme.FontSmall,
                    ForeColor = Theme.TextSub,
                    Location = new Point(400, 38),
                    AutoSize = true
                };
                if (yaklasan)
                    card.Controls.Add(new Label { Text = "⚠ Yaklaşan", Font = Theme.FontSmall, ForeColor = Theme.Warning, Location = new Point(750, 10), AutoSize = true });

                card.Controls.AddRange(new Control[] { lblDers, lblSinav, lblTarih, lblAciklama });
                pnlContent.Controls.Add(card);
                y += 85;
            }
        }

        // ─── BİLDİRİMLER ─────────────────────────────────────────────────
        private void ShowBildirimler()
        {
            SetPageTitle("🔔 Bildirimler");
            pnlContent.Controls.Clear();

            DataTable dt;
            try {
                dt = DbHelper.Query(
                   "SELECT b.GonderimTarihi, " +
                   "IIF(b.OgretmenId < 0, (SELECT a.AdSoyad FROM Adminler a WHERE a.AdminId = b.OgretmenId * -1), " +
                   "(SELECT o.AdSoyad FROM Ogretmenler o WHERE o.OgretmenId=b.OgretmenId)) AS Ogretmen, " +
                   "b.Baslik, b.Mesaj " +
                   "FROM Bildirimler AS b " +
                   "WHERE b.TumSiniflar = 1 OR b.SinifId = @sid " +
                   "ORDER BY b.BildirimId DESC",
                    DbHelper.P("@sid", sinifId));
            } catch (Exception ex) {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20,20) });
                return;
            }

            if (dt.Rows.Count == 0)
            {
                pnlContent.Controls.Add(new Label {
                    Text = "📭  Henüz bildirim yok.",
                    Font = Theme.FontNormal, ForeColor = Theme.TextSub,
                    Location = new Point(20, 20), AutoSize = true
                });
                return;
            }

            int y = 15;
            foreach (DataRow row in dt.Rows)
            {
                var baslik   = row["Baslik"].ToString();
                var ogretmen = row["Ogretmen"].ToString();
                var mesaj    = row["Mesaj"].ToString();
                var tarih    = Convert.ToDateTime(row["GonderimTarihi"]).ToString("dd.MM.yyyy HH:mm");

                var card = new Panel {
                    Location = new Point(20, y),
                    Size = new Size(pnlContent.Width - 40, 90),
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle,
                    Cursor = Cursors.Hand,
                    Tag = new string[] { baslik, ogretmen, mesaj, tarih }
                };
                card.Paint += (s, pe) => {
                    pe.Graphics.DrawLine(new Pen(Color.FromArgb(37, 99, 235), 3), 0, 0, 0, ((Panel)s).Height);
                };

                card.Controls.Add(new Label {
                    Text = baslik,
                    Font = Theme.FontBold, ForeColor = Theme.Primary,
                    Location = new Point(18, 10), AutoSize = true
                });
                card.Controls.Add(new Label {
                    Text = "👨‍🏫 " + ogretmen + "   📅 " + tarih,
                    Font = Theme.FontSmall, ForeColor = Theme.TextSub,
                    Location = new Point(18, 35), AutoSize = true
                });
                card.Controls.Add(new Label {
                    Text = mesaj,
                    Font = Theme.FontNormal, ForeColor = Theme.TextMain,
                    Location = new Point(18, 58), Size = new Size(780, 22), AutoEllipsis = true
                });
                card.Controls.Add(new Label {
                    Text = "›",
                    Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                    ForeColor = Color.FromArgb(180,180,200),
                    Location = new Point(810, 28), AutoSize = true
                });

                // Tıklayınca detay penceresi
                EventHandler acDetay = (s, ev) => {
                    var data = (string[])((s is Panel ? (Panel)s : (Panel)((Control)s).Parent)).Tag;
                    BildirimDetayGoster(data[0], data[1], data[2], data[3]);
                };
                card.Click += acDetay;
                foreach (Control ctrl in card.Controls) ctrl.Click += acDetay;

                pnlContent.Controls.Add(card);
                y += 100;
            }
        }

        private DataGridView MakeGrid()
        {
            var dgv = new DataGridView {
                ReadOnly = true,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = Theme.FontNormal,
                AllowUserToResizeColumns = false,
                AllowUserToResizeRows = false,
                AllowUserToOrderColumns = false,
                ColumnHeadersDefaultCellStyle = { WrapMode = DataGridViewTriState.False },
                MultiSelect = false,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.FromArgb(226, 232, 240)
            };
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);
            dgv.DefaultCellStyle.SelectionForeColor = Theme.TextMain;
            dgv.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 38;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 34;
            return dgv;
        }

        private void BildirimDetayGoster(string baslik, string gonderen, string mesaj, string tarih)
        {
            var frm = new Form {
                Text = "Bildirim Detayı", Size = new Size(520, 340),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false, MinimizeBox = false, BackColor = Color.White
            };
            frm.Controls.Add(new Panel { Dock = DockStyle.Top, Height = 8, BackColor = Theme.Primary });
            frm.Controls.Add(new Label {
                Text = baslik, Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Theme.TextMain, Location = new Point(25, 28), Size = new Size(460, 30), AutoEllipsis = true
            });
            frm.Controls.Add(new Label {
                Text = "Gönderen: " + gonderen + "   |   " + tarih,
                Font = Theme.FontSmall, ForeColor = Theme.TextSub, Location = new Point(25, 65), Size = new Size(460, 18)
            });
            frm.Controls.Add(new Panel { Location = new Point(25, 90), Size = new Size(460, 1), BackColor = Theme.Border });
            var txtM = new TextBox {
                Text = mesaj, Location = new Point(25, 105), Size = new Size(460, 150),
                Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10F), ForeColor = Theme.TextMain,
                BackColor = Color.White, ScrollBars = ScrollBars.Vertical
            };
            frm.Controls.Add(txtM);
            var btnK = new Button {
                Text = "Kapat", Location = new Point(195, 268), Size = new Size(120, 36),
                BackColor = Theme.Primary, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold, Cursor = Cursors.Hand
            };
            btnK.FlatAppearance.BorderSize = 0;
            btnK.Click += (s, e) => frm.Close();
            frm.Controls.Add(btnK);
            frm.ShowDialog(this);
        }
    }
}
