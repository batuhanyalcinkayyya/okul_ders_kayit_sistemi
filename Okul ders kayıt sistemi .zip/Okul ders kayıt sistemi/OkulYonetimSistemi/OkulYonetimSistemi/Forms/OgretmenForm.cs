using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    // dynamic yerine kullanılan yardımcı sınıf (CS0656 hatasını önler)
    public partial class OgretmenForm : Form
    {
        int ogretmenId;
        string adSoyad;
        private Button activeBtn;

        public OgretmenForm(int id, string ad)
        {
            ogretmenId = id; adSoyad = ad;
            InitializeComponent();
            SetupEvents();
            ShowDersProgram();
        }

        private void SetupEvents()
        {
            this.FormClosing += (s, e) => { Application.OpenForms[0]?.Show(); };
            this.Resize += (s, e) => {
                pnlSidebar.Height = this.ClientSize.Height;
                pnlTopBar.Width   = this.ClientSize.Width - 220;
                pnlContent.Width  = this.ClientSize.Width - 220;
                pnlContent.Height = this.ClientSize.Height - 60;
                foreach (Control c in pnlContent.Controls)
                    if (c is DataGridView || c is Panel) c.Width = pnlContent.Width - c.Left - 20;
                // Ders programı gibi elle çizilen sayfaları yeniden yükle
                if (activeBtn == btnDersProgram) ShowDersProgram();
            };
            this.MaximizeBox     = true;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            btnDersProgram.Click += (s, e) => { SetActive(btnDersProgram); ShowDersProgram(); };
            btnOgrenciler.Click  += (s, e) => { SetActive(btnOgrenciler);  ShowOgrenciler(); };
            btnDevamsizlik.Click += (s, e) => { SetActive(btnDevamsizlik); ShowDevamsizlik(); };
            btnSinav.Click       += (s, e) => { SetActive(btnSinav);       ShowSinavEkle(); };
            btnNotGuncelle.Click += (s, e) => { SetActive(btnNotGuncelle); ShowNotGuncelle(); };
            btnBildirim.Click    += (s, e) => { SetActive(btnBildirim);    ShowBildirim(); };
            btnCikis.Click       += (s, e) => this.Close();
            try { this.Icon = new System.Drawing.Icon("42496school_99040.ico"); } catch { }
            lblKullanici.Text = adSoyad;
            SetActive(btnDersProgram);
        }

        private Button MakeSideBtn(string text, int y)
        {
            var btn = new Button
            {
                Text = text,
                Location = new Point(0, y),
                Size = new Size(220, 42),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(148, 163, 184),
                Font = Theme.FontNormal,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(15, 0, 0, 0),
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(51, 65, 85);
            return btn;
        }

        private void SetActive(Button btn)
        {
            if (activeBtn != null) { activeBtn.BackColor = Color.Transparent; activeBtn.ForeColor = Color.FromArgb(148, 163, 184); }
            activeBtn = btn;
            btn.BackColor = Theme.Primary;
            btn.ForeColor = Color.White;
        }

        private void SetPageTitle(string t)
        {
            var l = pnlTopBar.Controls["lblPageTitle"] as Label;
            if (l != null) l.Text = t;
        }

        // ─── DERS PROGRAMI ───────────────────────────────────────────────
        private void ShowDersProgram()
        {
            SetPageTitle("📅 Ders Programım");
            pnlContent.Controls.Clear();

            string[] gunler = { "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma" };
            string[] saatEtiket = { "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00" };

            DataTable dt;
            try
            {
                dt = DbHelper.Query(
                    "SELECT dp.Gun, dp.Saat, d.DersAdi, s.SinifAdi " +
                    "FROM (DersProgrami dp " +
                    "INNER JOIN Dersler d ON dp.DersId = d.DersId) " +
                    "INNER JOIN Siniflar s ON dp.SinifId = s.SinifId " +
                    "WHERE dp.OgretmenId = @id",
                    DbHelper.P("@id", ogretmenId));
            }
            catch (Exception ex)
            {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20, 20) });
                return;
            }

            int cellW = 155, cellH = 60, startX = 90, startY = 70;

            for (int g = 0; g < gunler.Length; g++)
                pnlContent.Controls.Add(new Label
                {
                    Text = gunler[g],
                    Size = new Size(cellW, 36),
                    Location = new Point(startX + g * cellW, 25),
                    BackColor = Color.FromArgb(30, 41, 59),
                    ForeColor = Color.White,
                    Font = Theme.FontBold,
                    TextAlign = ContentAlignment.MiddleCenter
                });

            for (int s = 0; s < saatEtiket.Length; s++)
            {
                pnlContent.Controls.Add(new Label
                {
                    Text = saatEtiket[s],
                    Size = new Size(80, cellH),
                    Location = new Point(5, startY + s * cellH),
                    Font = Theme.FontSmall,
                    ForeColor = Theme.TextSub,
                    TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = Color.White
                });

                for (int g = 0; g < gunler.Length; g++)
                {
                    string ders = "", sinif = "";
                    foreach (DataRow row in dt.Rows)
                        if (row["Gun"].ToString() == gunler[g] && Convert.ToInt32(row["Saat"]) == s + 1)
                        { ders = row["DersAdi"].ToString(); sinif = row["SinifAdi"].ToString(); break; }

                    var cell = new Panel
                    {
                        Size = new Size(cellW - 2, cellH - 2),
                        Location = new Point(startX + g * cellW, startY + s * cellH),
                        BackColor = string.IsNullOrEmpty(ders) ? Color.FromArgb(248, 250, 252) : Color.FromArgb(240, 253, 244),
                        BorderStyle = BorderStyle.FixedSingle
                    };
                    if (!string.IsNullOrEmpty(ders))
                    {
                        cell.Controls.Add(new Label { Text = ders, Font = Theme.FontBold, ForeColor = Theme.Success, Location = new Point(5, 5), Size = new Size(cellW - 15, 22), AutoEllipsis = true });
                        cell.Controls.Add(new Label { Text = "🎓 " + sinif, Font = Theme.FontSmall, ForeColor = Theme.TextSub, Location = new Point(5, 30), Size = new Size(cellW - 15, 18), AutoEllipsis = true });
                    }
                    pnlContent.Controls.Add(cell);
                }
            }
        }

        // ─── ÖĞRENCİLERİM ───────────────────────────────────────────────
        private void ShowOgrenciler()
        {
            SetPageTitle("👥 Öğrencilerim");
            pnlContent.Controls.Clear();

            DataTable dt;
            try
            {
                dt = DbHelper.Query(
                "SELECT DISTINCT o.OgrenciId, o.AdSoyad, " +
                "(SELECT s.SinifAdi FROM Siniflar s WHERE s.SinifId = o.SinifId) AS SinifAdi " +
                "FROM Ogrenciler o " +
                "WHERE o.SinifId IN (SELECT dp.SinifId FROM DersProgrami dp WHERE dp.OgretmenId = @id) " +
                "ORDER BY o.AdSoyad",
             DbHelper.P("@id", ogretmenId));
            }
            catch (Exception ex)
            {
                pnlContent.Controls.Add(new Label { Text = "Hata: " + ex.Message, ForeColor = Theme.Danger, AutoSize = true, Location = new Point(20, 20) });
                return;
            }

            var dgv = MakeGrid();
            dgv.Dock = DockStyle.Fill;
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Okul No", DataPropertyName = "OgrenciId", FillWeight = 8 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ad Soyad", DataPropertyName = "AdSoyad", FillWeight = 35 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınıf", DataPropertyName = "SinifAdi", FillWeight = 20 });
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.DataSource = dt;
            pnlContent.Controls.Add(dgv);
        }

        // ─── DEVAMSIZLIK EKLE ────────────────────────────────────────────
        private void ShowDevamsizlik()
        {
            SetPageTitle("📌 Devamsızlık Ekle");
            pnlContent.Controls.Clear();

            var lblSinif = new Label { Text = "Sınıf:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(20, 25), AutoSize = true };
            var cbSinif = new ComboBox { Location = new Point(80, 21), Size = new Size(160, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            try
            {
                var siniflar = DbHelper.Query("SELECT DISTINCT s.SinifId, s.SinifAdi FROM Siniflar s INNER JOIN DersProgrami dp ON s.SinifId=dp.SinifId WHERE dp.OgretmenId=@id", DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in siniflar.Rows)
                    cbSinif.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
                cbSinif.DisplayMember = "Ad";
            }
            catch { }

           

            var btnYukle = new Button
            {
                Text = "Öğrencileri Getir",
                Location = new Point(500, 19),
                Size = new Size(150, 32),
                BackColor = Theme.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold
            };
            btnYukle.FlatAppearance.BorderSize = 0;

            // DÜZENLENEBİLİR grid - MakeGrid() değil, özel oluşturuyoruz
            var dgv = new DataGridView
            {
                ReadOnly = false,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = Theme.FontNormal,
                EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
                Location = new Point(20, 70),
                Size = new Size(pnlContent.Width - 40, 430)
            };
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 38;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 34;

            var btnKaydet = new Button
            {
                Text = "💾 Devamsızlıkları Kaydet",
                Location = new Point(20, 515),
                Size = new Size(220, 38),
                BackColor = Theme.Success,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold,
                Visible = false
            };
            btnKaydet.FlatAppearance.BorderSize = 0;

            btnYukle.Click += (s, e) => {
                if (cbSinif.SelectedItem == null) { MessageBox.Show("Sınıf seçin!"); return; }
                int sinifId = ((IdAd)cbSinif.SelectedItem).Id;

                dgv.Columns.Clear();
                dgv.Rows.Clear();

                try
                {
                    var dt = DbHelper.Query(
                        "SELECT o.OgrenciId, o.AdSoyad FROM Ogrenciler o WHERE o.SinifId=@sid ORDER BY o.AdSoyad",
                        DbHelper.P("@sid", sinifId));

                    dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "OgrenciId", HeaderText = "Okul Numarası", ReadOnly = true, FillWeight = 10 });
                    dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "AdSoyad", HeaderText = "Ad Soyad", ReadOnly = true, FillWeight = 50 });
                    dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Devamsizlik", HeaderText = "Devamsızlık (Gün)", FillWeight = 40 });
                    dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    foreach (DataRow r in dt.Rows)
                    {
                        int ogrId = Convert.ToInt32(r["OgrenciId"]);
                        int mevcutDev = 0;
                        try
                        {
                            var dersler2 = DbHelper.Query(
    "SELECT DersId FROM DersProgrami WHERE SinifId=@sid AND OgretmenId=@oid",
    DbHelper.P("@sid", sinifId), DbHelper.P("@oid", ogretmenId));
                            foreach (DataRow d2 in dersler2.Rows)
                            {
                                var kayit = DbHelper.Query(
                                    "SELECT Devamsizlik FROM Kayitlar WHERE OgrenciId=@ogr AND DersId=@did",
                                    DbHelper.P("@ogr", ogrId), DbHelper.P("@did", Convert.ToInt32(d2["DersId"])));
                                if (kayit.Rows.Count > 0 && kayit.Rows[0]["Devamsizlik"] != DBNull.Value)
                                {
                                    mevcutDev = Convert.ToInt32(kayit.Rows[0]["Devamsizlik"]);
                                    break;
                                }
                            }
                        }
                        catch { }

                        int idx = dgv.Rows.Add();
                        dgv.Rows[idx].Cells["OgrenciId"].Value  = ogrId;
                        dgv.Rows[idx].Cells["AdSoyad"].Value    = r["AdSoyad"];
                        dgv.Rows[idx].Cells["Devamsizlik"].Value = mevcutDev;
                    }

                    btnKaydet.Tag = sinifId;
                    btnKaydet.Visible = true;
                }
                catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            };

            btnKaydet.Click += (s, e) => {
                if (btnKaydet.Tag == null) return;
                int sinifId = (int)btnKaydet.Tag;
                int basarili = 0;

                foreach (DataGridViewRow row in dgv.Rows)
                {
                    if (row.IsNewRow) continue;
                    int ogrId = Convert.ToInt32(row.Cells["OgrenciId"].Value);
                    int dev = 0;
                    int.TryParse(row.Cells["Devamsizlik"].Value?.ToString(), out dev);

                    try
                    {
                        var dersler = DbHelper.Query(
                            "SELECT DersId FROM DersProgrami WHERE SinifId=@sid AND OgretmenId=@oid",
                            DbHelper.P("@sid", sinifId), DbHelper.P("@oid", ogretmenId));

                        foreach (DataRow dr in dersler.Rows)
                        {
                            int dersId = Convert.ToInt32(dr["DersId"]);
                            var kayit = DbHelper.Query(
                                "SELECT KayitId FROM Kayitlar WHERE OgrenciId=@ogr AND DersId=@did",
                                DbHelper.P("@ogr", ogrId), DbHelper.P("@did", dersId));

                            if (kayit.Rows.Count > 0)
                            {
                                DbHelper.Execute(
                                    "UPDATE Kayitlar SET Devamsizlik=@dev WHERE OgrenciId=@ogr AND DersId=@did",
                                    DbHelper.P("@dev", dev), DbHelper.P("@ogr", ogrId), DbHelper.P("@did", dersId));
                            }
                            else
                            {
                                DbHelper.Execute(
                                    "INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik, OzursuzGun) VALUES (@ogr, @did, 0, 0, @dev, 0)",
                                    DbHelper.P("@ogr", ogrId), DbHelper.P("@did", dersId), DbHelper.P("@dev", dev));
                            }
                        }
                        basarili++;
                    }
                    catch (Exception ex) { MessageBox.Show("Kayıt hatası: " + ex.Message); break; }
                }
                MessageBox.Show($"{basarili} öğrencinin devamsızlığı kaydedildi!", "Başarılı",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            pnlContent.Controls.AddRange(new Control[] {
                lblSinif, cbSinif, btnYukle, dgv, btnKaydet
            });
        }

        // ─── SINAV EKLE ──────────────────────────────────────────────────
        private void ShowSinavEkle()
        {
            SetPageTitle("📋 Sınav Ekle");
            pnlContent.Controls.Clear();

            var pnlForm = new Panel
            {
                Location = new Point(20, 20),
                Size = new Size(pnlContent.Width - 40, 380),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label L(string t, int x, int y) => new Label { Text = t, Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(x, y), AutoSize = true };
            TextBox TB(int x, int y, int w = 320) => new TextBox { Location = new Point(x, y), Size = new Size(w, 28), Font = Theme.FontNormal, BorderStyle = BorderStyle.FixedSingle };

            pnlForm.Controls.Add(L("Sınav Adı:", 20, 25));
            var txtSinavAdi = TB(130, 21, 350);
            pnlForm.Controls.Add(txtSinavAdi);

            pnlForm.Controls.Add(L("Sınıf:", 20, 75));
            var cbSinif = new ComboBox { Location = new Point(130, 71), Size = new Size(200, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            try
            {
                var siniflar = DbHelper.Query("SELECT DISTINCT s.SinifId, s.SinifAdi FROM Siniflar s INNER JOIN DersProgrami dp ON s.SinifId=dp.SinifId WHERE dp.OgretmenId=@id", DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in siniflar.Rows) cbSinif.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
                cbSinif.DisplayMember = "Ad";
            }
            catch { }
            pnlForm.Controls.Add(cbSinif);

            pnlForm.Controls.Add(L("Ders:", 20, 125));
            var cbDers = new ComboBox { Location = new Point(130, 121), Size = new Size(200, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            try
            {
                var dersler = DbHelper.Query("SELECT DersId, DersAdi FROM Dersler WHERE OgretmenId=@id", DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in dersler.Rows) cbDers.Items.Add(new IdAd { Id = Convert.ToInt32(r["DersId"]), Ad = r["DersAdi"].ToString() });
                cbDers.DisplayMember = "Ad";
            }
            catch { }
            pnlForm.Controls.Add(cbDers);

            pnlForm.Controls.Add(L("Tarih:", 20, 175));
            var dtp = new DateTimePicker { Location = new Point(130, 171), Size = new Size(200, 28), Format = DateTimePickerFormat.Short };
            pnlForm.Controls.Add(dtp);

            pnlForm.Controls.Add(L("Saat:", 20, 225));
            var txtSaat = TB(130, 221, 120);
            txtSaat.Text = "09:00";
            pnlForm.Controls.Add(txtSaat);

            pnlForm.Controls.Add(L("Açıklama:", 20, 275));
            var txtAciklama = TB(130, 271, 450);
            pnlForm.Controls.Add(txtAciklama);

            var btnEkle = new Button
            {
                Text = "✅ Sınavı Ekle",
                Location = new Point(20, 325),
                Size = new Size(200, 38),
                BackColor = Theme.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold
            };
            btnEkle.FlatAppearance.BorderSize = 0;
            btnEkle.Click += (s, e) => {
                if (string.IsNullOrEmpty(txtSinavAdi.Text) || cbSinif.SelectedItem == null || cbDers.SelectedItem == null)
                { MessageBox.Show("Lütfen tüm alanları doldurun!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                IdAd seciliSinif = (IdAd)cbSinif.SelectedItem;
                IdAd seciliDers = (IdAd)cbDers.SelectedItem;

                try
                {
                    DbHelper.Execute(
                        "INSERT INTO SinavTakvimi (SinavAdi, SinifId, DersId, SinavTarihi, SinavSaati, Aciklama) " +
                        "VALUES (@ad, @sid, @did, @tarih, @saat, @acik)",
                        DbHelper.P("@ad", txtSinavAdi.Text),
                        DbHelper.P("@sid", seciliSinif.Id),
                        DbHelper.P("@did", seciliDers.Id),
                        DbHelper.P("@tarih", dtp.Value.Date),
                        DbHelper.P("@saat", txtSaat.Text),
                        DbHelper.P("@acik", txtAciklama.Text));
                    MessageBox.Show("Sınav başarıyla eklendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSinavAdi.Text = ""; txtAciklama.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            pnlForm.Controls.Add(btnEkle);

            // Mevcut sınavlar
            var lblMevcut = new Label { Text = "Eklenen Sınavlar:", Font = Theme.FontHeader, ForeColor = Theme.TextMain, Location = new Point(20, 415), AutoSize = true };
            var dgv = MakeGrid();
            dgv.Location = new Point(20, 445);
            dgv.Size = new Size(pnlContent.Width - 40, 130);
            DataTable dtSinavlar;
            try
            {
                dtSinavlar = DbHelper.Query(
                    "SELECT st.SinavAdi, s.SinifAdi, d.DersAdi, st.SinavTarihi, st.SinavSaati " +
                    "FROM (SinavTakvimi st INNER JOIN Siniflar s ON st.SinifId=s.SinifId) " +
                    "INNER JOIN Dersler d ON st.DersId=d.DersId " +
                    "WHERE d.OgretmenId=@id ORDER BY st.SinavTarihi DESC",
                    DbHelper.P("@id", ogretmenId));
                dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınav", DataPropertyName = "SinavAdi", FillWeight = 25 });
                dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınıf", DataPropertyName = "SinifAdi", FillWeight = 15 });
                dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ders", DataPropertyName = "DersAdi", FillWeight = 20 });
                dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tarih", DataPropertyName = "SinavTarihi", FillWeight = 20 });
                dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Saat", DataPropertyName = "SinavSaati", FillWeight = 10 });
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgv.DataSource = dtSinavlar;
            }
            catch { }

            pnlContent.Controls.AddRange(new Control[] { pnlForm, lblMevcut, dgv });
        }

        // ─── NOT GİR / GÜNCELLE ─────────────────────────────────────────
        private void ShowNotGuncelle()
        {
            SetPageTitle("📝 Not Gir / Güncelle");
            pnlContent.Controls.Clear();

            // ── Filtre paneli ──────────────────────────────────────────
            var pnlFiltre = new Panel
            {
                Location = new Point(20, 20),
                Size = new Size(pnlContent.Width - 40, 70),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            pnlFiltre.Controls.Add(new Label { Text = "Sınıf:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(20, 22), AutoSize = true });
            var cbSinif = new ComboBox { Location = new Point(75, 18), Size = new Size(160, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            try
            {
                var siniflar = DbHelper.Query(
                    "SELECT DISTINCT s.SinifId, s.SinifAdi FROM Siniflar s " +
                    "INNER JOIN DersProgrami dp ON s.SinifId=dp.SinifId WHERE dp.OgretmenId=@id",
                    DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in siniflar.Rows)
                    cbSinif.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
                cbSinif.DisplayMember = "Ad";
            }
            catch { }
            pnlFiltre.Controls.Add(cbSinif);

            pnlFiltre.Controls.Add(new Label { Text = "Ders:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(260, 22), AutoSize = true });
            var cbDers = new ComboBox { Location = new Point(305, 18), Size = new Size(200, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            try
            {
                var dersler = DbHelper.Query("SELECT DersId, DersAdi FROM Dersler WHERE OgretmenId=@id", DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in dersler.Rows)
                    cbDers.Items.Add(new IdAd { Id = Convert.ToInt32(r["DersId"]), Ad = r["DersAdi"].ToString() });
                cbDers.DisplayMember = "Ad";
            }
            catch { }
            pnlFiltre.Controls.Add(cbDers);

            var btnGetir = new Button
            {
                Text = "Öğrencileri Getir",
                Location = new Point(535, 16),
                Size = new Size(150, 32),
                BackColor = Theme.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold,
                Cursor = Cursors.Hand
            };
            btnGetir.FlatAppearance.BorderSize = 0;
            pnlFiltre.Controls.Add(btnGetir);

            // ── Not tablosu ────────────────────────────────────────────
            var dgv = new DataGridView
            {
                ReadOnly = false,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = Theme.FontNormal,
                EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
                Location = new Point(20, 110),
                Size = new Size(pnlContent.Width - 40, 360)
            };
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 36;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 32;

            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "OgrenciId", HeaderText = "OgrenciId", DataPropertyName = "OgrenciId", Visible = false });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "KayitId", HeaderText = "KayitId", DataPropertyName = "KayitId", Visible = false });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "AdSoyad", HeaderText = "Ad Soyad", DataPropertyName = "AdSoyad", FillWeight = 40, ReadOnly = true });
            var colVize = new DataGridViewTextBoxColumn { Name = "Vize", HeaderText = "Vize (0-100)", DataPropertyName = "Vize", FillWeight = 20 };
            var colFinal = new DataGridViewTextBoxColumn { Name = "Final", HeaderText = "Final (0-100)", DataPropertyName = "Final", FillWeight = 20 };
            var colOrt = new DataGridViewTextBoxColumn { Name = "Ortalama", HeaderText = "Ortalama", DataPropertyName = "Ortalama", FillWeight = 20, ReadOnly = true };
            dgv.Columns.AddRange(colVize, colFinal, colOrt);
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Ortalamayı anlık hesapla
            dgv.CellValueChanged += (s, e) => {
                if (e.RowIndex < 0) return;
                var row = dgv.Rows[e.RowIndex];
                if (int.TryParse(row.Cells["Vize"].Value?.ToString(), out int v) &&
                    int.TryParse(row.Cells["Final"].Value?.ToString(), out int f))
                {
                    double ort = v * 0.4 + f * 0.6;
                    row.Cells["Ortalama"].Value = ort.ToString("F1");
                }
            };
            dgv.CurrentCellDirtyStateChanged += (s, e) => {
                if (dgv.IsCurrentCellDirty) dgv.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };

            // Getir butonu
            btnGetir.Click += (s, e) => {
                if (cbSinif.SelectedItem == null || cbDers.SelectedItem == null)
                { MessageBox.Show("Lütfen sınıf ve ders seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                int sinifId = ((IdAd)cbSinif.SelectedItem).Id;
                int dersId = ((IdAd)cbDers.SelectedItem).Id;

                try
                {
                    // Önce o sınıftaki öğrencileri çek
                    var dtOgrenci = DbHelper.Query(
                        "SELECT OgrenciId, AdSoyad FROM Ogrenciler WHERE SinifId=@sid ORDER BY AdSoyad",
                        DbHelper.P("@sid", sinifId));

                    // Mevcut notları ayrı çek
                    var dtNot = DbHelper.Query(
                        "SELECT KayitId, OgrenciId, Vize, Final FROM Kayitlar WHERE DersId=@did",
                        DbHelper.P("@did", dersId));

                    dgv.Rows.Clear();
                    foreach (DataRow r in dtOgrenci.Rows)
                    {
                        int oid = Convert.ToInt32(r["OgrenciId"]);
                        DataRow[] notlar = dtNot.Select("OgrenciId=" + oid);
                        int kayitId = 0, vize = 0, final = 0;
                        string ortalama = "—";
                        if (notlar.Length > 0)
                        {
                            kayitId = Convert.ToInt32(notlar[0]["KayitId"]);
                            vize = Convert.ToInt32(notlar[0]["Vize"]);
                            final = Convert.ToInt32(notlar[0]["Final"]);
                            ortalama = (vize * 0.4 + final * 0.6).ToString("F1");
                        }
                        int idx = dgv.Rows.Add();
                        dgv.Rows[idx].Cells["OgrenciId"].Value = oid;
                        dgv.Rows[idx].Cells["KayitId"].Value = kayitId;
                        dgv.Rows[idx].Cells["AdSoyad"].Value = r["AdSoyad"];
                        dgv.Rows[idx].Cells["Vize"].Value = vize;
                        dgv.Rows[idx].Cells["Final"].Value = final;
                        dgv.Rows[idx].Cells["Ortalama"].Value = ortalama;
                    }
                    dgv.Tag = new object[] { sinifId, dersId };
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            // ── Kaydet butonu ──────────────────────────────────────────
            var btnKaydet = new Button
            {
                Text = "💾  Notları Kaydet",
                Location = new Point(20, 490),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(22, 163, 74),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold,
                Cursor = Cursors.Hand
            };
            btnKaydet.FlatAppearance.BorderSize = 0;
            btnKaydet.Click += (s, e) => {
                if (dgv.Tag == null || dgv.Rows.Count == 0)
                { MessageBox.Show("Önce öğrencileri getirin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                var arr = (object[])dgv.Tag;
                int dersId = (int)arr[1];
                int hataSayisi = 0, guncelleme = 0;

                foreach (DataGridViewRow row in dgv.Rows)
                {
                    if (row.IsNewRow) continue;
                    if (!int.TryParse(row.Cells["Vize"].Value?.ToString(), out int vize) || vize < 0 || vize > 100) { hataSayisi++; continue; }
                    if (!int.TryParse(row.Cells["Final"].Value?.ToString(), out int final) || final < 0 || final > 100) { hataSayisi++; continue; }

                    int ogrenciId = Convert.ToInt32(row.Cells["OgrenciId"].Value);
                    int kayitId = Convert.ToInt32(row.Cells["KayitId"].Value);

                    try
                    {
                        if (kayitId > 0)
                        {
                            // Güncelle
                            DbHelper.Execute(
                                "UPDATE Kayitlar SET Vize=@v, Final=@f WHERE KayitId=@kid",
                                DbHelper.P("@v", vize), DbHelper.P("@f", final), DbHelper.P("@kid", kayitId));
                        }
                        else
                        {
                            // Yeni kayıt ekle
                            DbHelper.Execute(
                                "INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik) VALUES (@oid, @did, @v, @f, 0)",
                                DbHelper.P("@oid", ogrenciId), DbHelper.P("@did", dersId),
                                DbHelper.P("@v", vize), DbHelper.P("@f", final));
                        }
                        guncelleme++;
                    }
                    catch { hataSayisi++; }
                }

                string mesaj = $"{guncelleme} öğrencinin notu başarıyla kaydedildi.";
                if (hataSayisi > 0) mesaj += $"\n{hataSayisi} satırda hata oluştu (not 0-100 arası olmalı).";
                MessageBox.Show(mesaj, "Kayıt Sonucu", MessageBoxButtons.OK,
                    hataSayisi > 0 ? MessageBoxIcon.Warning : MessageBoxIcon.Information);

                // Tabloyu yenile
                btnGetir.PerformClick();
            };

            pnlContent.Controls.AddRange(new Control[] { pnlFiltre, dgv, btnKaydet });
        }

        // ─── BİLDİRİM GÖNDER ────────────────────────────────────────────
        private void ShowBildirim()
        {
            SetPageTitle("🔔 Bildirim Gönder");
            pnlContent.Controls.Clear();

            // Form paneli
            var pnlForm = new Panel
            {
                Location = new Point(20, 15),
                Size = new Size(pnlContent.Width - 40, 220),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            pnlForm.Controls.Add(new Label { Text = "Başlık:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(20, 20), AutoSize = true });
            var txtBaslik = new TextBox { Location = new Point(100, 16), Size = new Size(500, 28), Font = Theme.FontNormal, BorderStyle = BorderStyle.FixedSingle };
            pnlForm.Controls.Add(txtBaslik);

            pnlForm.Controls.Add(new Label { Text = "Mesaj:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(20, 60), AutoSize = true });
            var txtMesaj = new TextBox { Location = new Point(100, 56), Size = new Size(700, 70), Font = Theme.FontNormal, BorderStyle = BorderStyle.FixedSingle, Multiline = true };
            pnlForm.Controls.Add(txtMesaj);

            pnlForm.Controls.Add(new Label { Text = "Sınıf:", Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(20, 145), AutoSize = true });
            var cbSinif = new ComboBox { Location = new Point(100, 141), Size = new Size(200, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            cbSinif.Items.Add(new IdAd { Id = -1, Ad = "── Tüm Sınıflar ──" });
            try
            {
                var siniflar = DbHelper.Query("SELECT DISTINCT s.SinifId, s.SinifAdi FROM Siniflar s INNER JOIN DersProgrami dp ON s.SinifId=dp.SinifId WHERE dp.OgretmenId=@id", DbHelper.P("@id", ogretmenId));
                foreach (DataRow r in siniflar.Rows)
                    cbSinif.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
            }
            catch { }
            cbSinif.SelectedIndex = 0;
            pnlForm.Controls.Add(cbSinif);

            var btnGonder = new Button
            {
                Text = "🔔  Bildirimi Gönder",
                Location = new Point(340, 138),
                Size = new Size(200, 38),
                BackColor = Theme.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold,
                Cursor = Cursors.Hand
            };
            btnGonder.FlatAppearance.BorderSize = 0;
            btnGonder.Click += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtBaslik.Text) || string.IsNullOrWhiteSpace(txtMesaj.Text))
                { MessageBox.Show("Başlık ve mesaj boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                IdAd secili = cbSinif.SelectedItem as IdAd;
                int sinifId = secili != null ? secili.Id : -1;
                int tumSiniflar = sinifId == -1 ? 1 : 0;

                try
                {
                    DbHelper.Execute(
                        "INSERT INTO Bildirimler (OgretmenId, SinifId, Baslik, Mesaj, GonderimTarihi, TumSiniflar) VALUES (@oid, @sid, @bas, @mes, @tar, @tum)",
                        DbHelper.P("@oid", ogretmenId),
                        DbHelper.P("@sid", sinifId == -1 ? (object)DBNull.Value : sinifId),
                        DbHelper.P("@bas", txtBaslik.Text),
                        DbHelper.P("@mes", txtMesaj.Text),
                        DbHelper.P("@tar", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                        DbHelper.P("@tum", (byte)tumSiniflar));

                    MessageBox.Show("✅ Bildirim başarıyla gönderildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBaslik.Text = ""; txtMesaj.Text = "";
                    GecmisBildirimleriYukle(dgvGecmis);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            pnlForm.Controls.Add(btnGonder);
            pnlContent.Controls.Add(pnlForm);

            // Geçmiş bildirimler
            pnlContent.Controls.Add(new Label
            {
                Text = "📬  Gönderilen Bildirimler",
                Font = Theme.FontHeader,
                ForeColor = Theme.TextMain,
                Location = new Point(20, 248),
                AutoSize = true
            });

            dgvGecmis = MakeGrid();
            dgvGecmis.Location = new Point(20, 278);
            dgvGecmis.Size = new Size(pnlContent.Width - 40, 290);
            dgvGecmis.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tarih", DataPropertyName = "GonderimTarihi", Name = "GonderimTarihi", FillWeight = 18 });
            dgvGecmis.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Başlık", DataPropertyName = "Baslik", Name = "Baslik", FillWeight = 25 });
            dgvGecmis.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınıf", DataPropertyName = "SinifAdi", Name = "SinifAdi", FillWeight = 15 });
            dgvGecmis.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Mesaj", DataPropertyName = "Mesaj", Name = "Mesaj", FillWeight = 42 });
            dgvGecmis.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            GecmisBildirimleriYukle(dgvGecmis);
            dgvGecmis.CellClick += (s, e) => {
                if (e.RowIndex < 0) return;
                var row = dgvGecmis.Rows[e.RowIndex];
                string bas  = row.Cells["Baslik"]?.Value?.ToString() ?? "";
                string sin  = row.Cells["SinifAdi"]?.Value?.ToString() ?? "";
                string mes  = row.Cells["Mesaj"]?.Value?.ToString() ?? "";
                string tar  = row.Cells["GonderimTarihi"]?.Value?.ToString() ?? "";
                BildirimDetayGoster(bas, sin, mes, tar);
            };
            pnlContent.Controls.Add(dgvGecmis);
        }

        private DataGridView dgvGecmis;

        private void GecmisBildirimleriYukle(DataGridView dgv)
        {
            try
            {
                var dt = DbHelper.Query(
                    "SELECT b.GonderimTarihi, b.Baslik, b.Mesaj, " +
                    "IIF(b.TumSiniflar=1, 'Tüm Sınıflar', s.SinifAdi) AS SinifAdi " +
                    "FROM Bildirimler AS b LEFT JOIN Siniflar AS s ON b.SinifId = s.SinifId " +
                    "WHERE b.OgretmenId = @id OR b.TumOgretmenler = 1 ORDER BY b.BildirimId DESC",
                    DbHelper.P("@id", ogretmenId));
                dgv.DataSource = dt;
            }
            catch { }
        }

        private void BildirimDetayGoster(string baslik, string sinif, string mesaj, string tarih)
        {
            var frm = new Form {
                Text = "Bildirim Detayı",
                Size = new Size(520, 340),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false, MinimizeBox = false,
                BackColor = Color.White
            };
            var pnlTop = new Panel { Dock = DockStyle.Top, Height = 8, BackColor = Theme.Primary };
            frm.Controls.Add(pnlTop);
            frm.Controls.Add(new Label {
                Text = baslik, Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Theme.TextMain, Location = new Point(25, 28), Size = new Size(460, 30), AutoEllipsis = true
            });
            frm.Controls.Add(new Label {
                Text = "Sınıf: " + sinif + "   |   " + tarih,
                Font = Theme.FontSmall, ForeColor = Theme.TextSub, Location = new Point(25, 65), Size = new Size(460, 18)
            });
            frm.Controls.Add(new Panel { Location = new Point(25, 90), Size = new Size(460, 1), BackColor = Theme.Border });
            var txtM = new TextBox {
                Text = mesaj, Location = new Point(25, 105), Size = new Size(460, 150),
                Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10F), ForeColor = Theme.TextMain,
                BackColor = Color.White, ScrollBars = ScrollBars.Vertical
            };
            frm.Controls.Add(txtM);
            var btnK = new Button {
                Text = "Kapat", Location = new Point(195, 268), Size = new Size(120, 36),
                BackColor = Theme.Primary, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold, Cursor = Cursors.Hand
            };
            btnK.FlatAppearance.BorderSize = 0;
            btnK.Click += (s, e) => frm.Close();
            frm.Controls.Add(btnK);
            frm.ShowDialog(this);
        }

        private DataGridView MakeGrid()
        {
            var dgv = new DataGridView
            {
                ReadOnly = true,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = Theme.FontNormal,
                AllowUserToResizeColumns = false,
                AllowUserToResizeRows = false,
                AllowUserToOrderColumns = false,
                MultiSelect = false,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.FromArgb(226, 232, 240)
            };
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);
            dgv.DefaultCellStyle.SelectionForeColor = Theme.TextMain;
            dgv.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 38;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 34;
            return dgv;
        }
    }

    internal class IdAd
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public override string ToString() => Ad;
    }
}