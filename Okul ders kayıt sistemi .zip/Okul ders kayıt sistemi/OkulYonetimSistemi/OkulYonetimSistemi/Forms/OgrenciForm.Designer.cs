namespace WindowsFormsApp6
{
    partial class OgrenciForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlSidebar      = new System.Windows.Forms.Panel();
            this.pnlTopBar       = new System.Windows.Forms.Panel();
            this.pnlContent      = new System.Windows.Forms.Panel();
            this.lblPageTitle    = new System.Windows.Forms.Label();
            this.lblLogo         = new System.Windows.Forms.Label();
            this.lblAd           = new System.Windows.Forms.Label();
            this.lblSinif        = new System.Windows.Forms.Label();
            this.btnDersProgrami = new System.Windows.Forms.Button();
            this.btnNotlar       = new System.Windows.Forms.Button();
            this.btnSinavTakvimi = new System.Windows.Forms.Button();
            this.btnBildirim     = new System.Windows.Forms.Button();
            this.btnCikis        = new System.Windows.Forms.Button();

            this.pnlSidebar.SuspendLayout();
            this.pnlTopBar.SuspendLayout();
            this.SuspendLayout();

            // pnlSidebar
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.pnlSidebar.Controls.Add(this.lblLogo);
            this.pnlSidebar.Controls.Add(this.lblAd);
            this.pnlSidebar.Controls.Add(this.lblSinif);
            this.pnlSidebar.Controls.Add(this.btnDersProgrami);
            this.pnlSidebar.Controls.Add(this.btnNotlar);
            this.pnlSidebar.Controls.Add(this.btnSinavTakvimi);
            this.pnlSidebar.Controls.Add(this.btnBildirim);
            this.pnlSidebar.Controls.Add(this.btnCikis);
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Size     = new System.Drawing.Size(220, 660);

            // lblLogo
            this.lblLogo.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location  = new System.Drawing.Point(0, 25);
            this.lblLogo.Size      = new System.Drawing.Size(220, 30);
            this.lblLogo.Text      = "Öğrenci Paneli";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblAd
            this.lblAd.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAd.ForeColor = System.Drawing.Color.White;
            this.lblAd.Location  = new System.Drawing.Point(25, 76);
            this.lblAd.Size      = new System.Drawing.Size(170, 20);
            this.lblAd.Text      = "";

            // lblSinif
            this.lblSinif.AutoSize  = true;
            this.lblSinif.Font      = new System.Drawing.Font("Segoe UI", 8F);
            this.lblSinif.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.lblSinif.Location  = new System.Drawing.Point(25, 100);
            this.lblSinif.Text      = "";

            // btnDersProgrami
            this.btnDersProgrami.BackColor = System.Drawing.Color.Transparent;
            this.btnDersProgrami.FlatAppearance.BorderSize = 0;
            this.btnDersProgrami.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDersProgrami.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDersProgrami.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnDersProgrami.Location  = new System.Drawing.Point(0, 155);
            this.btnDersProgrami.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnDersProgrami.Size      = new System.Drawing.Size(220, 42);
            this.btnDersProgrami.Text      = "Ders Programım";
            this.btnDersProgrami.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnNotlar
            this.btnNotlar.BackColor = System.Drawing.Color.Transparent;
            this.btnNotlar.FlatAppearance.BorderSize = 0;
            this.btnNotlar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotlar.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnNotlar.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnNotlar.Location  = new System.Drawing.Point(0, 205);
            this.btnNotlar.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnNotlar.Size      = new System.Drawing.Size(220, 42);
            this.btnNotlar.Text      = "Notlarım";
            this.btnNotlar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnSinavTakvimi
            this.btnSinavTakvimi.BackColor = System.Drawing.Color.Transparent;
            this.btnSinavTakvimi.FlatAppearance.BorderSize = 0;
            this.btnSinavTakvimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSinavTakvimi.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSinavTakvimi.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnSinavTakvimi.Location  = new System.Drawing.Point(0, 255);
            this.btnSinavTakvimi.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnSinavTakvimi.Size      = new System.Drawing.Size(220, 42);
            this.btnSinavTakvimi.Text      = "Sınav Takvimi";
            this.btnSinavTakvimi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnBildirim
            this.btnBildirim.BackColor = System.Drawing.Color.Transparent;
            this.btnBildirim.FlatAppearance.BorderSize = 0;
            this.btnBildirim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBildirim.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBildirim.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnBildirim.Location  = new System.Drawing.Point(0, 305);
            this.btnBildirim.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnBildirim.Size      = new System.Drawing.Size(220, 42);
            this.btnBildirim.Text      = "Bildirimler";
            this.btnBildirim.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // btnCikis
            this.btnCikis.BackColor = System.Drawing.Color.Transparent;
            this.btnCikis.FlatAppearance.BorderSize = 0;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.Font      = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCikis.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.btnCikis.Location  = new System.Drawing.Point(0, 590);
            this.btnCikis.Padding   = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnCikis.Size      = new System.Drawing.Size(220, 42);
            this.btnCikis.Text      = "Çıkış";
            this.btnCikis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // pnlTopBar
            this.pnlTopBar.BackColor = System.Drawing.Color.White;
            this.pnlTopBar.Controls.Add(this.lblPageTitle);
            this.pnlTopBar.Location  = new System.Drawing.Point(220, 0);
            this.pnlTopBar.Size      = new System.Drawing.Size(880, 60);

            // lblPageTitle
            this.lblPageTitle.AutoSize  = true;
            this.lblPageTitle.Font      = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.lblPageTitle.Location  = new System.Drawing.Point(25, 18);
            this.lblPageTitle.Name      = "lblPageTitle";
            this.lblPageTitle.Text      = "Ders Programım";

            // pnlContent
            this.pnlContent.AutoScroll = true;
            this.pnlContent.BackColor  = System.Drawing.Color.FromArgb(248, 250, 252);
            this.pnlContent.Location   = new System.Drawing.Point(220, 60);
            this.pnlContent.Size       = new System.Drawing.Size(880, 600);

            // OgrenciForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode  = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor      = System.Drawing.Color.FromArgb(248, 250, 252);
            this.ClientSize     = new System.Drawing.Size(1100, 660);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlTopBar);
            this.Controls.Add(this.pnlSidebar);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text          = "Öğrenci Paneli";

            this.pnlTopBar.ResumeLayout(false);
            this.pnlTopBar.PerformLayout();
            this.pnlSidebar.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel  pnlSidebar;
        private System.Windows.Forms.Panel  pnlTopBar;
        private System.Windows.Forms.Panel  pnlContent;
        private System.Windows.Forms.Label  lblPageTitle;
        private System.Windows.Forms.Label  lblLogo;
        private System.Windows.Forms.Label  lblAd;
        private System.Windows.Forms.Label  lblSinif;
        private System.Windows.Forms.Button btnDersProgrami;
        private System.Windows.Forms.Button btnNotlar;
        private System.Windows.Forms.Button btnSinavTakvimi;
        private System.Windows.Forms.Button btnBildirim;
        private System.Windows.Forms.Button btnCikis;
    }
}
