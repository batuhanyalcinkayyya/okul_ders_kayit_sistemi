using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class AdminForm : Form
    {
        int adminId;
        string adSoyad;
        private Button activeBtn;


        public AdminForm(int id, string ad)
        {
            adminId = id; adSoyad = ad;
            InitializeComponent();
            SetupEvents();
            ShowDersKayit();
        }

        private void SetupEvents()
        {
            this.FormClosing += (s, e) => Application.OpenForms[0]?.Show();
            this.Resize += (s, e) => {
                pnlSidebar.Height = this.ClientSize.Height;
                pnlTopBar.Width   = this.ClientSize.Width - 220;
                pnlContent.Width  = this.ClientSize.Width - 220;
                pnlContent.Height = this.ClientSize.Height - 60;
                foreach (Control c in pnlContent.Controls)
                    if (c is DataGridView || c is Panel) c.Width = pnlContent.Width - c.Left - 20;
            };
            this.MaximizeBox     = true;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            btnDersKayit.Click    += (s, e) => { SetActive(btnDersKayit);    ShowDersKayit(); };
            btnDersProg.Click     += (s, e) => { SetActive(btnDersProg);     ShowDersProg(); };
            btnOgrenciKayit.Click += (s, e) => { SetActive(btnOgrenciKayit); ShowOgrenciKayit(); };
            btnDevamsizlik.Click  += (s, e) => { SetActive(btnDevamsizlik);  ShowDevamsizlik(); };
            btnBildirim.Click     += (s, e) => { SetActive(btnBildirim);     ShowBildirim(); };
            btnCikis.Click        += (s, e) => this.Close();
            try { this.Icon = new System.Drawing.Icon("42496school_99040.ico"); } catch { }
            lblKullanici.Text = adSoyad;
            SetActive(btnDersKayit);
        }

        // ── YARDIMCI ────────────────────────────────────────────────────
        private Button MakeSideBtn(string text, int y)
        {
            var btn = new Button {
                Text = text, Location = new Point(0, y), Size = new Size(220, 42),
                FlatStyle = FlatStyle.Flat, ForeColor = Color.FromArgb(148, 163, 184),
                Font = Theme.FontNormal, TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(15, 0, 0, 0), BackColor = Color.Transparent, Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 41, 59);
            return btn;
        }

        private void SetActive(Button btn)
        {
            if (activeBtn != null) { activeBtn.BackColor = Color.Transparent; activeBtn.ForeColor = Color.FromArgb(148, 163, 184); }
            activeBtn = btn; btn.BackColor = Theme.Primary; btn.ForeColor = Color.White;
        }

        private void SetTitle(string t) { (pnlTopBar.Controls["lblTitle"] as Label).Text = t; }

        private DataGridView MakeGrid(int x, int y, int w, int h)
        {
            var dgv = new DataGridView {
                ReadOnly = true, AllowUserToAddRows = false, BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None, RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = Theme.FontNormal, Location = new Point(x, y), Size = new Size(w, h),
                AllowUserToResizeColumns = false,
                AllowUserToResizeRows = false,
                AllowUserToOrderColumns = false,
                MultiSelect = false,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.FromArgb(226, 232, 240)
            };
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);
            dgv.DefaultCellStyle.SelectionForeColor = Theme.TextMain;
            dgv.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 38;
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 34;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            return dgv;
        }

        private Button MakeBtn(string text, int x, int y, Color bg, int w = 180, int h = 36)
        {
            var btn = new Button {
                Text = text, Location = new Point(x, y), Size = new Size(w, h),
                BackColor = bg, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold, Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private Label Lbl(string t, int x, int y) =>
            new Label { Text = t, Font = Theme.FontBold, ForeColor = Theme.TextMain, Location = new Point(x, y), AutoSize = true };

        private TextBox TB(int x, int y, int w = 220) =>
            new TextBox { Location = new Point(x, y), Size = new Size(w, 28), Font = Theme.FontNormal, BorderStyle = BorderStyle.FixedSingle };

        private Panel Kart(int x, int y, int w, int h)
        {
            var p = new Panel { Location = new Point(x, y), Size = new Size(w, h), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            return p;
        }

        // ================================================================
        // 1. DERS KAYDI
        // ================================================================
        private void ShowDersKayit()
        {
            SetTitle("📚 Ders Kaydı");
            pnlContent.Controls.Clear();

            var kart = Kart(20, 20, 840, 110);

            kart.Controls.Add(Lbl("Ders Adı:", 20, 22));
            var txtAd = TB(110, 18, 240);
            kart.Controls.Add(txtAd);

            kart.Controls.Add(Lbl("Öğretmen:", 375, 22));
            var cbOgr = new ComboBox { Location = new Point(465, 18), Size = new Size(250, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            OgretmenDoldur(cbOgr);
            kart.Controls.Add(cbOgr);

            var btnEkle = MakeBtn("✅ Ders Ekle", 20, 62, Theme.Primary, 160);
            btnEkle.Click += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtAd.Text) || cbOgr.SelectedItem == null)
                { MessageBox.Show("Ders adı ve öğretmen zorunlu!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                try {
                    DbHelper.Execute("INSERT INTO Dersler (DersAdi, OgretmenId) VALUES (@a, @o)",
                        DbHelper.P("@a", txtAd.Text.Trim()), DbHelper.P("@o", ((IdAd)cbOgr.SelectedItem).Id));
                    MessageBox.Show("Ders eklendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtAd.Text = ""; cbOgr.SelectedIndex = -1;
                    ShowDersKayit();
                } catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            };
            kart.Controls.Add(btnEkle);
            pnlContent.Controls.Add(kart);

            pnlContent.Controls.Add(new Label { Text = "Kayıtlı Dersler", Font = Theme.FontHeader, ForeColor = Theme.TextMain, Location = new Point(20, 148), AutoSize = true });

            var dgv = MakeGrid(20, 175, pnlContent.Width - 20 - 20, 380);
            var colSil = new DataGridViewButtonColumn { HeaderText = "İşlem", Text = "Sil", UseColumnTextForButtonValue = true, FillWeight = 10, Name = "colSil" };
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ID", DataPropertyName = "DersId", FillWeight = 8, Name = "DersId", Visible = false });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ders Adı", DataPropertyName = "DersAdi", FillWeight = 40 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Öğretmen", DataPropertyName = "AdSoyad", FillWeight = 42 });
            dgv.Columns.Add(colSil);
            try {
                dgv.DataSource = DbHelper.Query(
                    "SELECT d.DersId, d.DersAdi, o.AdSoyad FROM Dersler d INNER JOIN Ogretmenler o ON d.OgretmenId=o.OgretmenId ORDER BY d.DersAdi");
            } catch { }
            dgv.CellClick += (s, e) => {
                if (e.RowIndex < 0 || dgv.Columns[e.ColumnIndex].Name != "colSil") return;
                int id = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["DersId"].Value);
                if (MessageBox.Show("Ders silinsin mi?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
                    try { DbHelper.Execute("DELETE FROM Dersler WHERE DersId=@id", DbHelper.P("@id", id)); ShowDersKayit(); }
                    catch (Exception ex) { MessageBox.Show("Silinemedi: " + ex.Message); }
                }
            };
            pnlContent.Controls.Add(dgv);
        }

        // ================================================================
        // 2. DERS PROGRAMI
        // ================================================================
        private void ShowDersProg()
        {
            SetTitle("📅 Ders Programı Düzenleme");
            pnlContent.Controls.Clear();

            var kart = Kart(20, 20, 840, 160);

            kart.Controls.Add(Lbl("Ders:", 20, 22));
            var cbDers = new ComboBox { Location = new Point(80, 18), Size = new Size(220, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            DersDoldur(cbDers);
            kart.Controls.Add(cbDers);

            kart.Controls.Add(Lbl("Sınıf:", 320, 22));
            var cbSinif = new ComboBox { Location = new Point(375, 18), Size = new Size(180, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            SinifDoldur(cbSinif);
            kart.Controls.Add(cbSinif);

            kart.Controls.Add(Lbl("Gün:", 20, 70));
            var cbGun = new ComboBox { Location = new Point(80, 66), Size = new Size(160, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            foreach (var g in new[] { "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma" }) cbGun.Items.Add(g);
            kart.Controls.Add(cbGun);

            kart.Controls.Add(Lbl("Saat:", 260, 70));
            var cbSaat = new ComboBox { Location = new Point(310, 66), Size = new Size(180, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            string[] saatler = { "1 - 08:00", "2 - 09:00", "3 - 10:00", "4 - 11:00", "5 - 12:00", "6 - 13:00", "7 - 14:00", "8 - 15:00" };
            for (int i = 0; i < saatler.Length; i++) cbSaat.Items.Add(new IdAd { Id = i + 1, Ad = saatler[i] });
            cbSaat.DisplayMember = "Ad";
            kart.Controls.Add(cbSaat);

            var btnEkle = MakeBtn("✅ Programa Ekle", 20, 115, Theme.Primary, 180);
            btnEkle.Click += (s, e) => {
                if (cbDers.SelectedItem == null || cbSinif.SelectedItem == null || cbGun.SelectedItem == null || cbSaat.SelectedItem == null)
                { MessageBox.Show("Tüm alanları doldurun!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                int dersId = ((IdAd)cbDers.SelectedItem).Id;
                int sinifId = ((IdAd)cbSinif.SelectedItem).Id;
                string gun = cbGun.SelectedItem.ToString();
                int saat = ((IdAd)cbSaat.SelectedItem).Id;
                int ogretmenId = 0;
                try { ogretmenId = Convert.ToInt32(DbHelper.Scalar("SELECT OgretmenId FROM Dersler WHERE DersId=@id", DbHelper.P("@id", dersId))); }
                catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); return; }
                // Çakışma kontrolü
                try {
                    int sayi = Convert.ToInt32(DbHelper.Scalar(
                        "SELECT COUNT(*) FROM DersProgrami WHERE SinifId=@s AND Gun=@g AND Saat=@sa",
                        DbHelper.P("@s", sinifId), DbHelper.P("@g", gun), DbHelper.P("@sa", saat)));
                    if (sayi > 0) { MessageBox.Show("Bu sınıf için o gün/saat dolu!", "Çakışma", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                } catch { }
                try {
                    DbHelper.Execute("INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (@si, @di, @oi, @g, @sa)",
                        DbHelper.P("@si", sinifId), DbHelper.P("@di", dersId), DbHelper.P("@oi", ogretmenId), DbHelper.P("@g", gun), DbHelper.P("@sa", saat));
                    MessageBox.Show("Programa eklendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ShowDersProg();
                } catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            };
            kart.Controls.Add(btnEkle);
            pnlContent.Controls.Add(kart);

            pnlContent.Controls.Add(new Label { Text = "Mevcut Ders Programı", Font = Theme.FontHeader, ForeColor = Theme.TextMain, Location = new Point(20, 196), AutoSize = true });
            var dgv = MakeGrid(20, 222, pnlContent.Width - 20 - 20, 340);
            var colSil = new DataGridViewButtonColumn { HeaderText = "İşlem", Text = "Sil", UseColumnTextForButtonValue = true, FillWeight = 10, Name = "colSil" };
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ProgramId", DataPropertyName = "ProgramId", Visible = false, Name = "ProgramId" });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınıf", DataPropertyName = "SinifAdi", FillWeight = 14 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ders", DataPropertyName = "DersAdi", FillWeight = 22 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Öğretmen", DataPropertyName = "AdSoyad", FillWeight = 22 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Gün", DataPropertyName = "Gun", FillWeight = 14 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Saat", DataPropertyName = "Saat", FillWeight = 8 });
            dgv.Columns.Add(colSil);
            try {
                dgv.DataSource = DbHelper.Query(
                    "SELECT dp.ProgramId, s.SinifAdi, d.DersAdi, o.AdSoyad, dp.Gun, dp.Saat " +
                    "FROM ((DersProgrami dp INNER JOIN Siniflar s ON dp.SinifId=s.SinifId) " +
                    "INNER JOIN Dersler d ON dp.DersId=d.DersId) INNER JOIN Ogretmenler o ON dp.OgretmenId=o.OgretmenId " +
                    "ORDER BY s.SinifAdi, dp.Gun, dp.Saat");
            } catch { }
            dgv.CellClick += (s, e) => {
                if (e.RowIndex < 0 || dgv.Columns[e.ColumnIndex].Name != "colSil") return;
                int id = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["ProgramId"].Value);
                if (MessageBox.Show("Program kaydı silinsin mi?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
                    try { DbHelper.Execute("DELETE FROM DersProgrami WHERE ProgramId=@id", DbHelper.P("@id", id)); ShowDersProg(); }
                    catch (Exception ex) { MessageBox.Show("Silinemedi: " + ex.Message); }
                }
            };
            pnlContent.Controls.Add(dgv);
        }

        // ================================================================
        // 3. ÖĞRENCİ KAYDI
        // ================================================================
        private void ShowOgrenciKayit()
        {
            SetTitle("👤 Öğrenci Kaydı");
            pnlContent.Controls.Clear();

            var kart = Kart(20, 20, 840, 170);

            kart.Controls.Add(Lbl("Ad Soyad:", 20, 22));
            var txtAd = TB(120, 18, 220);
            kart.Controls.Add(txtAd);

            kart.Controls.Add(Lbl("TC Kimlik:", 360, 22));
            var txtTC = TB(455, 18, 160);
            txtTC.MaxLength = 11;
            txtTC.KeyPress += (s, e) => { if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back) e.Handled = true; };
            kart.Controls.Add(txtTC);

            kart.Controls.Add(Lbl("Şifre:", 20, 68));
            var txtSifre = TB(120, 64, 160);
            kart.Controls.Add(txtSifre);

            kart.Controls.Add(Lbl("Sınıf:", 300, 68));
            var cbSinif = new ComboBox { Location = new Point(355, 64), Size = new Size(180, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            SinifDoldur(cbSinif);
            kart.Controls.Add(cbSinif);

            var btnEkle = MakeBtn("👤 Öğrenci Ekle", 20, 118, Theme.Primary, 180);
            btnEkle.Click += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtTC.Text) ||
                    string.IsNullOrWhiteSpace(txtSifre.Text) || cbSinif.SelectedItem == null)
                { MessageBox.Show("Tüm alanlar zorunlu!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (txtTC.Text.Length != 11)
                { MessageBox.Show("TC 11 hane olmalıdır!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if ((txtTC.Text[10] - '0') % 2 != 0)
                { MessageBox.Show("TC son hanesi çift olmalıdır!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                try
                {
                    var tcKontrol = DbHelper.Query("SELECT OgrenciId FROM Ogrenciler WHERE TCKimlik=@tc", DbHelper.P("@tc", txtTC.Text));
                    if (tcKontrol.Rows.Count > 0)
                    {
                        MessageBox.Show("Bu TC kimlik numarası zaten kayıtlı!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                catch { }
                try
                {
                    int secilenSinifId = ((IdAd)cbSinif.SelectedItem).Id;
                    string sql = "INSERT INTO Ogrenciler (AdSoyad, TCKimlik, Sifre, SinifId) VALUES (@a, @tc, @s, @si)";
                    var cmd = new System.Data.OleDb.OleDbCommand();
                    cmd.Parameters.AddWithValue("@a", txtAd.Text.Trim());
                    cmd.Parameters.AddWithValue("@tc", txtTC.Text.Trim());
                    cmd.Parameters.AddWithValue("@s", txtSifre.Text.Trim());
                    cmd.Parameters.AddWithValue("@si", secilenSinifId);
                    using (var con = new System.Data.OleDb.OleDbConnection(DbHelper.ConnStr))
                    {
                        con.Open();
                        cmd.Connection = con;
                        cmd.CommandText = sql;
                        int etkilenen = cmd.ExecuteNonQuery();
                        if (etkilenen > 0)
                        {
                            MessageBox.Show("Öğrenci başarıyla eklendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtAd.Text = ""; txtTC.Text = ""; txtSifre.Text = ""; cbSinif.SelectedIndex = -1;
                            ShowOgrenciKayit();
                        }
                        else
                        {
                            MessageBox.Show("Kayıt yapılamadı, etkilenen satır 0!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kayıt hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            kart.Controls.Add(btnEkle);
            pnlContent.Controls.Add(kart);

            pnlContent.Controls.Add(new Label { Text = "Kayıtlı Öğrenciler", Font = Theme.FontHeader, ForeColor = Theme.TextMain, Location = new Point(20, 206), AutoSize = true });
            var dgv = MakeGrid(20, 232, pnlContent.Width - 20 - 20, 330);
            var colSil = new DataGridViewButtonColumn { HeaderText = "İşlem", Text = "Sil", UseColumnTextForButtonValue = true, FillWeight = 10, Name = "colSil" };
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ID", DataPropertyName = "OgrenciId", Visible = false, Name = "OgrenciId" });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ad Soyad", DataPropertyName = "AdSoyad", FillWeight = 30 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "TC Kimlik", DataPropertyName = "TCKimlik", FillWeight = 22 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Sınıf", DataPropertyName = "SinifAdi", FillWeight = 16 });
            dgv.Columns.Add(colSil);
            try {
                dgv.DataSource = DbHelper.Query(
                    "SELECT o.OgrenciId, o.AdSoyad, o.TCKimlik, " +
                    "(SELECT s.SinifAdi FROM Siniflar s WHERE s.SinifId = o.SinifId) AS SinifAdi " +
                    "FROM Ogrenciler o ORDER BY o.AdSoyad");
            } catch { }
            dgv.CellClick += (s, e) => {
                if (e.RowIndex < 0 || dgv.Columns[e.ColumnIndex].Name != "colSil") return;
                int id = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["OgrenciId"].Value);
                if (MessageBox.Show("Öğrenci silinsin mi? (Notlar da silinir!)", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
                    try { DbHelper.Execute("DELETE FROM Ogrenciler WHERE OgrenciId=@id", DbHelper.P("@id", id)); ShowOgrenciKayit(); }
                    catch (Exception ex) { MessageBox.Show("Silinemedi: " + ex.Message); }
                }
            };
            pnlContent.Controls.Add(dgv);
        }

        // ================================================================
        // 4. DEVAMSIZLIK YÖNETİMİ
        // ================================================================
        private void ShowDevamsizlik()
        {
            SetTitle("📌 Devamsızlık Yönetimi");
            pnlContent.Controls.Clear();

            var pnlFiltre = Kart(20, 20, 840, 65);
            pnlFiltre.Controls.Add(Lbl("Sınıf:", 20, 20));
            var cbSinif = new ComboBox { Location = new Point(75, 16), Size = new Size(180, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            SinifDoldur(cbSinif);
            pnlFiltre.Controls.Add(cbSinif);

            pnlFiltre.Controls.Add(Lbl("Ders:", 280, 20));
            var cbDers = new ComboBox { Location = new Point(325, 16), Size = new Size(220, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            pnlFiltre.Controls.Add(cbDers);

            // Sınıf değişince dersleri filtrele
            cbSinif.SelectedIndexChanged += (s, e) => {
                cbDers.Items.Clear();
                if (cbSinif.SelectedItem == null) return;
                int sid = ((IdAd)cbSinif.SelectedItem).Id;
                try {
                    var dt = DbHelper.Query(
                        "SELECT DISTINCT d.DersId, d.DersAdi FROM DersProgrami dp INNER JOIN Dersler d ON dp.DersId=d.DersId WHERE dp.SinifId=@sid",
                        DbHelper.P("@sid", sid));
                    foreach (DataRow r in dt.Rows) cbDers.Items.Add(new IdAd { Id = Convert.ToInt32(r["DersId"]), Ad = r["DersAdi"].ToString() });
                    cbDers.DisplayMember = "Ad";
                } catch { }
            };

            var btnGetir = MakeBtn("Öğrencileri Getir", 570, 14, Theme.Primary, 160);
            pnlFiltre.Controls.Add(btnGetir);
            pnlContent.Controls.Add(pnlFiltre);

            // Devamsızlık tablosu (düzenlenebilir)
            var dgv = new DataGridView {
                ReadOnly = false, AllowUserToAddRows = false, BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None, RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = Theme.FontNormal, Location = new Point(20, 100), Size = new Size(pnlContent.Width - 40, 380),
                EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2
            };
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 23, 42);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = Theme.FontBold;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersHeight = 36; dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 32; dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "OgrenciId", HeaderText = "OgrenciId", Visible = false, DataPropertyName = "OgrenciId" });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "KayitId", HeaderText = "KayitId", Visible = false, DataPropertyName = "KayitId" });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "AdSoyad", HeaderText = "Ad Soyad", DataPropertyName = "AdSoyad", ReadOnly = true, FillWeight = 35 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "DevamsizlikToplam", HeaderText = "Toplam Devamsızlık", DataPropertyName = "Devamsizlik", FillWeight = 22 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "OzursuzGun", HeaderText = "Özürsüz Gün", DataPropertyName = "OzursuzGun", FillWeight = 18 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "OzurluGun", HeaderText = "Özürlü Gün", DataPropertyName = "OzurluGun", FillWeight = 18, ReadOnly = true });

            pnlContent.Controls.Add(dgv);

            // Kaydet butonu
            var btnKaydet = MakeBtn("💾 Kaydet", 20, 494, Theme.Success, 160);
            btnKaydet.Visible = false;
            pnlContent.Controls.Add(btnKaydet);

            // Özürsüz değişince özürlüyü güncelle
            dgv.CellValueChanged += (s, e) => {
                if (e.RowIndex < 0) return;
                var row = dgv.Rows[e.RowIndex];
                if (int.TryParse(row.Cells["DevamsizlikToplam"].Value?.ToString(), out int toplam) &&
                    int.TryParse(row.Cells["OzursuzGun"].Value?.ToString(), out int ozursuz))
                {
                    int ozurlu = Math.Max(0, toplam - ozursuz);
                    row.Cells["OzurluGun"].Value = ozurlu;
                }
            };
            dgv.CurrentCellDirtyStateChanged += (s, e) => { if (dgv.IsCurrentCellDirty) dgv.CommitEdit(DataGridViewDataErrorContexts.Commit); };

            btnGetir.Click += (s, e) => {
                if (cbSinif.SelectedItem == null || cbDers.SelectedItem == null)
                { MessageBox.Show("Sınıf ve ders seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                int sinifId = ((IdAd)cbSinif.SelectedItem).Id;
                int dersId  = ((IdAd)cbDers.SelectedItem).Id;
                dgv.Rows.Clear();
                try {
                    var dtOgr = DbHelper.Query("SELECT OgrenciId, AdSoyad FROM Ogrenciler WHERE SinifId=@sid ORDER BY AdSoyad", DbHelper.P("@sid", sinifId));
                    var dtKay = DbHelper.Query("SELECT KayitId, OgrenciId, Devamsizlik, OzursuzGun FROM Kayitlar WHERE DersId=@did", DbHelper.P("@did", dersId));
                    foreach (DataRow r in dtOgr.Rows) {
                        int oid = Convert.ToInt32(r["OgrenciId"]);
                        DataRow[] k = dtKay.Select("OgrenciId=" + oid);
                        int kayitId = 0, dev = 0, ozursuz = 0;
                        if (k.Length > 0) {
                            kayitId = Convert.ToInt32(k[0]["KayitId"]);
                            dev = k[0]["Devamsizlik"] == DBNull.Value ? 0 : Convert.ToInt32(k[0]["Devamsizlik"]);
                            ozursuz = k[0]["OzursuzGun"] == DBNull.Value ? 0 : Convert.ToInt32(k[0]["OzursuzGun"]);
                        }
                        int idx = dgv.Rows.Add();
                        dgv.Rows[idx].Cells["OgrenciId"].Value = oid;
                        dgv.Rows[idx].Cells["KayitId"].Value = kayitId;
                        dgv.Rows[idx].Cells["AdSoyad"].Value = r["AdSoyad"];
                        dgv.Rows[idx].Cells["DevamsizlikToplam"].Value = dev;
                        dgv.Rows[idx].Cells["OzursuzGun"].Value = ozursuz;
                        dgv.Rows[idx].Cells["OzurluGun"].Value = Math.Max(0, dev - ozursuz);
                    }
                    dgv.Tag = new object[] { sinifId, dersId };
                    btnKaydet.Visible = true;
                } catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            };

            btnKaydet.Click += (s, e) => {
                if (dgv.Tag == null) return;
                var arr = (object[])dgv.Tag;
                int dersId = (int)arr[1];
                int ok = 0;
                foreach (DataGridViewRow row in dgv.Rows) {
                    if (row.IsNewRow) continue;
                    int oid = Convert.ToInt32(row.Cells["OgrenciId"].Value);
                    int kid = Convert.ToInt32(row.Cells["KayitId"].Value);
                    int.TryParse(row.Cells["DevamsizlikToplam"].Value?.ToString(), out int dev);
                    int.TryParse(row.Cells["OzursuzGun"].Value?.ToString(), out int ozursuz);
                    ozursuz = Math.Min(ozursuz, dev);
                    try {
                        if (kid > 0) {
                            DbHelper.Execute("UPDATE Kayitlar SET Devamsizlik=@d, OzursuzGun=@oz WHERE KayitId=@k",
                                DbHelper.P("@d", dev), DbHelper.P("@oz", ozursuz), DbHelper.P("@k", kid));
                        } else {
                            DbHelper.Execute("INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik, OzursuzGun) VALUES (@o, @d, 0, 0, @dev, @oz)",
                                DbHelper.P("@o", oid), DbHelper.P("@d", dersId), DbHelper.P("@dev", dev), DbHelper.P("@oz", ozursuz));
                        }
                        ok++;
                    } catch { }
                }
                MessageBox.Show($"{ok} öğrenci kaydedildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
        }

        // ================================================================
        // 5. BİLDİRİM GÖNDER
        // ================================================================
        private void ShowBildirim()
        {
            SetTitle("🔔 Bildirim Gönder");
            pnlContent.Controls.Clear();

            var kart = Kart(20, 20, 840, 200);

            kart.Controls.Add(Lbl("Başlık:", 20, 22));
            var txtBaslik = TB(100, 18, 550);
            kart.Controls.Add(txtBaslik);

            kart.Controls.Add(Lbl("Mesaj:", 20, 65));
            var txtMesaj = new TextBox {
                Location = new Point(100, 61), Size = new Size(700, 65),
                Font = Theme.FontNormal, BorderStyle = BorderStyle.FixedSingle, Multiline = true
            };
            kart.Controls.Add(txtMesaj);

            kart.Controls.Add(Lbl("Alıcı:", 20, 148));
            var cbHedef = new ComboBox { Location = new Point(80, 144), Size = new Size(220, 28), Font = Theme.FontNormal, DropDownStyle = ComboBoxStyle.DropDownList };
            cbHedef.Items.Add(new IdAd { Id = -1, Ad = "── Tüm Herkes ──" });
            cbHedef.Items.Add(new IdAd { Id = -2, Ad = "── Tüm Öğretmenler ──" });
            try {
                var siniflar = DbHelper.Query("SELECT SinifId, SinifAdi FROM Siniflar ORDER BY SinifAdi");
                foreach (DataRow r in siniflar.Rows)
                    cbHedef.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
            } catch { }
            cbHedef.DisplayMember = "Ad"; cbHedef.SelectedIndex = 0;
            kart.Controls.Add(cbHedef);

            var btnGonder = MakeBtn("🔔 Gönder", 330, 142, Theme.Primary, 160);
            btnGonder.Click += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtBaslik.Text) || string.IsNullOrWhiteSpace(txtMesaj.Text))
                { MessageBox.Show("Başlık ve mesaj boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                var hedef = (IdAd)cbHedef.SelectedItem;
                int sinifId = hedef.Id > 0 ? hedef.Id : 0;
                int tumSiniflar = (hedef.Id == -1) ? 1 : 0;
                int tumOgretmen = (hedef.Id == -2) ? 1 : 0;
                try {
                    DbHelper.Execute(
                        "INSERT INTO Bildirimler (OgretmenId, SinifId, Baslik, Mesaj, GonderimTarihi, TumSiniflar, TumOgretmenler) " +
                        "VALUES (@oid, @sid, @bas, @mes, @tar, @tum, @tumo)",
                        DbHelper.P("@oid", adminId* -1),
                        DbHelper.P("@sid", sinifId > 0 ? (object)sinifId : DBNull.Value),
                        DbHelper.P("@bas", txtBaslik.Text),
                        DbHelper.P("@mes", txtMesaj.Text),
                        DbHelper.P("@tar", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                        DbHelper.P("@tum", (byte)tumSiniflar),
                        DbHelper.P("@tumo", (byte)tumOgretmen));
                    MessageBox.Show("Bildirim gönderildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBaslik.Text = ""; txtMesaj.Text = "";
                    ShowBildirim();
                } catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            };
            kart.Controls.Add(btnGonder);
            pnlContent.Controls.Add(kart);

            pnlContent.Controls.Add(new Label { Text = "Gönderilen Bildirimler", Font = Theme.FontHeader, ForeColor = Theme.TextMain, Location = new Point(20, 236), AutoSize = true });
            var dgv = MakeGrid(20, 262, pnlContent.Width - 20 - 20, 300);
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tarih", DataPropertyName = "GonderimTarihi", Name = "GonderimTarihi", FillWeight = 18 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Başlık", DataPropertyName = "Baslik", Name = "Baslik", FillWeight = 25 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Alıcı", DataPropertyName = "Alici", Name = "Alici", FillWeight = 18 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Mesaj", DataPropertyName = "Mesaj", Name = "Mesaj", FillWeight = 39 });
            dgv.CellClick += (s, e) => {
                if (e.RowIndex < 0) return;
                var row = dgv.Rows[e.RowIndex];
                string bas  = row.Cells["Baslik"]?.Value?.ToString() ?? "";
                string ali  = row.Cells["Alici"]?.Value?.ToString() ?? "";
                string mes  = row.Cells["Mesaj"]?.Value?.ToString() ?? "";
                string tar  = row.Cells["GonderimTarihi"]?.Value?.ToString() ?? "";
                BildirimDetayGoster(bas, ali, mes, tar);
            };
            try {
                dgv.DataSource = DbHelper.Query(
                    "SELECT b.GonderimTarihi, b.Baslik, b.Mesaj, " +
                    "IIF(b.TumSiniflar=1,'Tüm Herkes',IIF(b.TumOgretmenler=1,'Tüm Öğretmenler',s.SinifAdi)) AS Alici " +
                    "FROM Bildirimler b LEFT JOIN Siniflar s ON b.SinifId=s.SinifId ORDER BY b.BildirimId DESC");
            } catch { }
            pnlContent.Controls.Add(dgv);
        }

        // ── CB DOLDURUCULAR ──────────────────────────────────────────────
        private void OgretmenDoldur(ComboBox cb)
        {
            try {
                var dt = DbHelper.Query("SELECT OgretmenId, AdSoyad FROM Ogretmenler ORDER BY AdSoyad");
                foreach (DataRow r in dt.Rows) cb.Items.Add(new IdAd { Id = Convert.ToInt32(r["OgretmenId"]), Ad = r["AdSoyad"].ToString() });
                cb.DisplayMember = "Ad";
            } catch { }
        }

        private void DersDoldur(ComboBox cb)
        {
            try {
                var dt = DbHelper.Query("SELECT d.DersId, d.DersAdi, o.AdSoyad FROM Dersler d INNER JOIN Ogretmenler o ON d.OgretmenId=o.OgretmenId ORDER BY d.DersAdi");
                foreach (DataRow r in dt.Rows)
                    cb.Items.Add(new IdAd { Id = Convert.ToInt32(r["DersId"]), Ad = r["DersAdi"] + " (" + r["AdSoyad"] + ")" });
                cb.DisplayMember = "Ad";
            } catch { }
        }

        private void SinifDoldur(ComboBox cb)
        {
            try {
                var dt = DbHelper.Query("SELECT SinifId, SinifAdi FROM Siniflar ORDER BY SinifAdi");
                foreach (DataRow r in dt.Rows) cb.Items.Add(new IdAd { Id = Convert.ToInt32(r["SinifId"]), Ad = r["SinifAdi"].ToString() });
                cb.DisplayMember = "Ad";
            } catch { }
        }

        private void BildirimDetayGoster(string baslik, string alici, string mesaj, string tarih)
        {
            var frm = new Form {
                Text = "Bildirim Detayı", Size = new Size(520, 340),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false, MinimizeBox = false, BackColor = Color.White
            };
            frm.Controls.Add(new Panel { Dock = DockStyle.Top, Height = 8, BackColor = Theme.Primary });
            frm.Controls.Add(new Label {
                Text = baslik, Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                ForeColor = Theme.TextMain, Location = new Point(25, 28), Size = new Size(460, 30), AutoEllipsis = true
            });
            frm.Controls.Add(new Label {
                Text = "Alıcı: " + alici + "   |   " + tarih,
                Font = Theme.FontSmall, ForeColor = Theme.TextSub, Location = new Point(25, 65), Size = new Size(460, 18)
            });
            frm.Controls.Add(new Panel { Location = new Point(25, 90), Size = new Size(460, 1), BackColor = Theme.Border });
            var txtM = new TextBox {
                Text = mesaj, Location = new Point(25, 105), Size = new Size(460, 150),
                Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10F), ForeColor = Theme.TextMain,
                BackColor = Color.White, ScrollBars = ScrollBars.Vertical
            };
            frm.Controls.Add(txtM);
            var btnK = new Button {
                Text = "Kapat", Location = new Point(195, 268), Size = new Size(120, 36),
                BackColor = Theme.Primary, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = Theme.FontBold, Cursor = Cursors.Hand
            };
            btnK.FlatAppearance.BorderSize = 0;
            btnK.Click += (s, e) => frm.Close();
            frm.Controls.Add(btnK);
            frm.ShowDialog(this);
        }
    }
}