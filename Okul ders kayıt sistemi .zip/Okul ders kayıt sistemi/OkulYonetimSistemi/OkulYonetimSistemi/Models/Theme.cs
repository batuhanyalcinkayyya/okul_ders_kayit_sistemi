using System.Drawing;

namespace WindowsFormsApp6
{
    public static class Theme
    {
        public static Color Primary     = Color.FromArgb(37, 99, 235);
        public static Color PrimaryDark = Color.FromArgb(29, 78, 216);
        public static Color Secondary   = Color.FromArgb(99, 102, 241);
        public static Color Success     = Color.FromArgb(16, 185, 129);
        public static Color Warning     = Color.FromArgb(245, 158, 11);
        public static Color Danger      = Color.FromArgb(239, 68, 68);
        public static Color BgLight     = Color.FromArgb(248, 250, 252);
        public static Color BgCard      = Color.White;
        public static Color TextMain    = Color.FromArgb(15, 23, 42);
        public static Color TextSub     = Color.FromArgb(100, 116, 139);
        public static Color Border      = Color.FromArgb(226, 232, 240);

        public static Font FontTitle  = new Font("Segoe UI", 18F, FontStyle.Bold);
        public static Font FontHeader = new Font("Segoe UI", 11F, FontStyle.Bold);
        public static Font FontNormal = new Font("Segoe UI", 9.5F);
        public static Font FontSmall  = new Font("Segoe UI", 8.5F);
        public static Font FontBold   = new Font("Segoe UI", 9.5F, FontStyle.Bold);
    }
}
