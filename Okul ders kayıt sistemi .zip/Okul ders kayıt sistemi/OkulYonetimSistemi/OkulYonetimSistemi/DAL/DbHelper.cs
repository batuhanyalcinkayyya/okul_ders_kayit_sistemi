using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public static class DbHelper
    {
        public static string DbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database", "OkulDb.accdb");
        public static string ConnStr => $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={DbPath}";

        public static DataTable Query(string sql, params OleDbParameter[] prms)
        {
            var dt = new DataTable();
            using (var con = new OleDbConnection(ConnStr))
            {
                con.Open();
                using (var cmd = new OleDbCommand(sql, con))
                {
                    foreach (var p in prms) cmd.Parameters.Add(p);
                    new OleDbDataAdapter(cmd).Fill(dt);
                }
            }
            return dt;
        }

        public static object Scalar(string sql, params OleDbParameter[] prms)
        {
            using (var con = new OleDbConnection(ConnStr))
            {
                con.Open();
                using (var cmd = new OleDbCommand(sql, con))
                {
                    foreach (var p in prms) cmd.Parameters.Add(p);
                    return cmd.ExecuteScalar();
                }
            }
        }

        public static void Execute(string sql, params OleDbParameter[] prms)
        {
            using (var con = new OleDbConnection(ConnStr))
            {
                con.Open();
                using (var cmd = new OleDbCommand(sql, con))
                {
                    foreach (var p in prms) cmd.Parameters.Add(p);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static OleDbParameter P(string name, object val) =>
            new OleDbParameter(name, val ?? DBNull.Value);
    }
}
