using System;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public static class DatabaseSetup
    {
        public static void KontrolEtVeOlustur()
        {
            if (File.Exists(DbHelper.DbPath)) return;
            MessageBox.Show(
                "OkulDb.accdb dosyası bulunamadı!\n\n" +
                "Lütfen OkulDb.accdb dosyasını Database klasörüne kopyalayın.\n\n" +
                "Klasör: " + AppDomain.CurrentDomain.BaseDirectory,
                "Veritabanı Bulunamadı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void TabloOlusturVeVeriEkle()
        {
            try
            {
                string[] sqls = {
                    "CREATE TABLE Siniflar (SinifId AUTOINCREMENT PRIMARY KEY, SinifAdi TEXT(20))",
                    "CREATE TABLE Ogretmenler (OgretmenId AUTOINCREMENT PRIMARY KEY, AdSoyad TEXT(100), TCKimlik TEXT(11), Sifre TEXT(50))",
                    "CREATE TABLE Ogrenciler (OgrenciId AUTOINCREMENT PRIMARY KEY, AdSoyad TEXT(100), TCKimlik TEXT(11), Sifre TEXT(50), SinifId INTEGER)",
                    "CREATE TABLE Adminler (AdminId AUTOINCREMENT PRIMARY KEY, AdSoyad TEXT(100), TCKimlik TEXT(11), Sifre TEXT(50))",
                    "CREATE TABLE Dersler (DersId AUTOINCREMENT PRIMARY KEY, DersAdi TEXT(100), OgretmenId INTEGER)",
                    "CREATE TABLE DersProgrami (ProgramId AUTOINCREMENT PRIMARY KEY, SinifId INTEGER, DersId INTEGER, OgretmenId INTEGER, Gun TEXT(20), Saat INTEGER)",
                    "CREATE TABLE Kayitlar (KayitId AUTOINCREMENT PRIMARY KEY, OgrenciId INTEGER, DersId INTEGER, Vize INTEGER, Final INTEGER, Devamsizlik INTEGER, OzursuzGun INTEGER DEFAULT 0)",
                    "CREATE TABLE SinavTakvimi (SinavId AUTOINCREMENT PRIMARY KEY, SinavAdi TEXT(200), SinifId INTEGER, DersId INTEGER, SinavTarihi DATETIME, SinavSaati TEXT(10), Aciklama TEXT(500))",
                    "CREATE TABLE Bildirimler (BildirimId AUTOINCREMENT PRIMARY KEY, OgretmenId INTEGER, SinifId INTEGER, Baslik TEXT(200), Mesaj TEXT(1000), GonderimTarihi DATETIME, TumSiniflar INTEGER DEFAULT 0, TumOgretmenler INTEGER DEFAULT 0)",

                    "INSERT INTO Siniflar (SinifAdi) VALUES ('9/A')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('9/B')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('10/A')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('10/B')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('11/A')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('11/B')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('12/A')",
                    "INSERT INTO Siniflar (SinifAdi) VALUES ('12/B')",

                    "INSERT INTO Ogretmenler (AdSoyad, TCKimlik, Sifre) VALUES ('Ahmet Yılmaz', '10000000002', '1234')",
                    "INSERT INTO Ogretmenler (AdSoyad, TCKimlik, Sifre) VALUES ('Fatma Kaya',   '10000000004', '1234')",
                    "INSERT INTO Ogretmenler (AdSoyad, TCKimlik, Sifre) VALUES ('Mehmet Demir', '10000000006', '1234')",

                    "INSERT INTO Ogrenciler (AdSoyad, TCKimlik, Sifre, SinifId) VALUES ('Ali Veli',   '20000000002', '1234', 1)",
                    "INSERT INTO Ogrenciler (AdSoyad, TCKimlik, Sifre, SinifId) VALUES ('Ayşe Çelik', '20000000004', '1234', 1)",
                    "INSERT INTO Ogrenciler (AdSoyad, TCKimlik, Sifre, SinifId) VALUES ('Hasan Kurt', '20000000006', '1234', 2)",

                    "INSERT INTO Adminler (AdSoyad, TCKimlik, Sifre) VALUES ('Yönetici Admin', '30000000002', '1234')",

                    "INSERT INTO Dersler (DersAdi, OgretmenId) VALUES ('Matematik', 1)",
                    "INSERT INTO Dersler (DersAdi, OgretmenId) VALUES ('Fizik',     2)",
                    "INSERT INTO Dersler (DersAdi, OgretmenId) VALUES ('Kimya',     3)",
                    "INSERT INTO Dersler (DersAdi, OgretmenId) VALUES ('Biyoloji',  2)",
                    "INSERT INTO Dersler (DersAdi, OgretmenId) VALUES ('Tarih',     3)",

                    "INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (1, 1, 1, 'Pazartesi', 1)",
                    "INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (1, 2, 2, 'Pazartesi', 2)",
                    "INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (1, 3, 3, 'Salı',      1)",
                    "INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (1, 4, 2, 'Salı',      2)",
                    "INSERT INTO DersProgrami (SinifId, DersId, OgretmenId, Gun, Saat) VALUES (1, 5, 3, 'Çarşamba',  1)",

                    "INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik, OzursuzGun) VALUES (1, 1, 70, 80, 3, 1)",
                    "INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik, OzursuzGun) VALUES (1, 2, 55, 65, 2, 2)",
                    "INSERT INTO Kayitlar (OgrenciId, DersId, Vize, Final, Devamsizlik, OzursuzGun) VALUES (1, 3, 90, 85, 0, 0)",
                };

                foreach (var sql in sqls)
                    try { DbHelper.Execute(sql); } catch { }

                MessageBox.Show(
                    "Tablolar ve örnek veriler oluşturuldu!\n\n" +
                    "─── Test Giriş Bilgileri ───\n" +
                    "Öğrenci  TC: 20000000002  Şifre: 1234\n" +
                    "Öğretmen TC: 10000000002  Şifre: 1234\n" +
                    "Admin    TC: 30000000002  Şifre: 1234",
                    "Kurulum Tamamlandı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Kurulum Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
