using System.Reflection;
[assembly: AssemblyTitle("OkulYonetimSistemi")]
[assembly: AssemblyVersion("2.0.0.0")]
