using System;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            DatabaseSetup.KontrolEtVeOlustur();
            Application.Run(new LoginForm());
        }
    }
}
